import { pgTable, text, serial, integer, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const careerResourcesTable = pgTable("career_resources", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  category: text("category").notNull(),
  content: text("content").notNull(),
  tags: text("tags").array().notNull().default([]),
  readTime: integer("read_time").notNull().default(5),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const careerRoadmapsTable = pgTable("career_roadmaps", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  domain: text("domain").notNull(),
  description: text("description").notNull(),
  steps: jsonb("steps").notNull().default([]),
  duration: text("duration").notNull(),
  difficulty: text("difficulty").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const skillRecommendationsTable = pgTable("skill_recommendations", {
  id: serial("id").primaryKey(),
  skill: text("skill").notNull(),
  category: text("category").notNull(),
  reason: text("reason").notNull(),
  priority: text("priority").notNull(),
  resources: text("resources").array().notNull().default([]),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertCareerResourceSchema = createInsertSchema(careerResourcesTable).omit({ id: true, createdAt: true });
export type InsertCareerResource = z.infer<typeof insertCareerResourceSchema>;
export type CareerResource = typeof careerResourcesTable.$inferSelect;

export const insertCareerRoadmapSchema = createInsertSchema(careerRoadmapsTable).omit({ id: true, createdAt: true });
export type InsertCareerRoadmap = z.infer<typeof insertCareerRoadmapSchema>;
export type CareerRoadmap = typeof careerRoadmapsTable.$inferSelect;

export const insertSkillRecommendationSchema = createInsertSchema(skillRecommendationsTable).omit({ id: true, createdAt: true });
export type InsertSkillRecommendation = z.infer<typeof insertSkillRecommendationSchema>;
export type SkillRecommendation = typeof skillRecommendationsTable.$inferSelect;
