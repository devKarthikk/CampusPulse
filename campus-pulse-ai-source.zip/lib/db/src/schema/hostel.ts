import { pgTable, text, serial, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const hostelInfoTable = pgTable("hostel_info", {
  id: serial("id").primaryKey(),
  hostelName: text("hostel_name").notNull(),
  roomNumber: text("room_number").notNull(),
  warden: text("warden").notNull(),
  wardenPhone: text("warden_phone").notNull(),
  address: text("address").notNull(),
  facilities: text("facilities").array().notNull().default([]),
  checkInTime: text("check_in_time").notNull(),
  checkOutTime: text("check_out_time").notNull(),
  rules: text("rules").array().notNull().default([]),
});

export const messMenuTable = pgTable("mess_menu", {
  id: serial("id").primaryKey(),
  day: text("day").notNull(),
  breakfast: text("breakfast").array().notNull().default([]),
  lunch: text("lunch").array().notNull().default([]),
  dinner: text("dinner").array().notNull().default([]),
  snacks: text("snacks").array().notNull().default([]),
});

export const leaveRequestsTable = pgTable("leave_requests", {
  id: serial("id").primaryKey(),
  fromDate: text("from_date").notNull(),
  toDate: text("to_date").notNull(),
  reason: text("reason").notNull(),
  status: text("status").notNull().default("pending"),
  submittedAt: timestamp("submitted_at", { withTimezone: true }).notNull().defaultNow(),
  remarks: text("remarks"),
});

export const complaintsTable = pgTable("complaints", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  category: text("category").notNull(),
  status: text("status").notNull().default("open"),
  submittedAt: timestamp("submitted_at", { withTimezone: true }).notNull().defaultNow(),
  resolvedAt: timestamp("resolved_at", { withTimezone: true }),
});

export const emergencyContactsTable = pgTable("emergency_contacts", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  role: text("role").notNull(),
  phone: text("phone").notNull(),
  available: text("available").notNull(),
});

export const insertLeaveRequestSchema = createInsertSchema(leaveRequestsTable).omit({ id: true, submittedAt: true });
export type InsertLeaveRequest = z.infer<typeof insertLeaveRequestSchema>;
export type LeaveRequest = typeof leaveRequestsTable.$inferSelect;

export const insertComplaintSchema = createInsertSchema(complaintsTable).omit({ id: true, submittedAt: true });
export type InsertComplaint = z.infer<typeof insertComplaintSchema>;
export type Complaint = typeof complaintsTable.$inferSelect;
