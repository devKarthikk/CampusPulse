import * as React from "react"
import { 
  useListChatSessions, 
  getListChatSessionsQueryKey, 
  useCreateChatSession, 
  useDeleteChatSession 
} from "@workspace/api-client-react"
import { Link, useLocation } from "wouter"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Skeleton } from "@/components/ui/skeleton"
import { MessageSquare, Plus, Trash2, ChevronRight, Sparkles } from "lucide-react"
import { formatDistanceToNow } from "date-fns"
import { useQueryClient } from "@tanstack/react-query"

export default function AIChat() {
  const [, setLocation] = useLocation()
  const queryClient = useQueryClient()
  
  const { data: sessions, isLoading } = useListChatSessions({ 
    query: { queryKey: getListChatSessionsQueryKey() } 
  })

  const createSession = useCreateChatSession()
  const deleteSession = useDeleteChatSession()

  const handleCreateSession = () => {
    createSession.mutate({ data: { title: "New Conversation" } }, {
      onSuccess: (newSession) => {
        queryClient.invalidateQueries({ queryKey: getListChatSessionsQueryKey() })
        setLocation(`/chat/${newSession.id}`)
      }
    })
  }

  const handleDelete = (e: React.MouseEvent, id: number) => {
    e.preventDefault()
    e.stopPropagation()
    deleteSession.mutate({ id }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListChatSessionsQueryKey() })
      }
    })
  }

  return (
    <div className="flex flex-col min-h-full">
      <header className="sticky top-0 z-30 bg-background/80 backdrop-blur-xl border-b px-4 py-4 md:px-8 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold font-heading">AI Assistant</h1>
          <p className="text-muted-foreground text-sm">Your intelligent campus companion</p>
        </div>
        <Button 
          onClick={handleCreateSession} 
          disabled={createSession.isPending}
          className="rounded-full shadow-md hover:shadow-lg transition-all"
        >
          <Plus className="w-5 h-5 md:mr-2" />
          <span className="hidden md:inline">New Chat</span>
        </Button>
      </header>

      <main className="flex-1 p-4 md:p-8 max-w-4xl mx-auto w-full">
        {isLoading ? (
          <div className="space-y-3">
            {Array(5).fill(0).map((_, i) => (
              <Skeleton key={i} className="h-20 w-full rounded-2xl" />
            ))}
          </div>
        ) : !sessions || sessions.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-center px-4 h-[60vh]">
            <div className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center mb-6">
              <Sparkles className="w-10 h-10 text-primary" />
            </div>
            <h3 className="font-heading text-xl font-semibold mb-2">How can I help you today?</h3>
            <p className="text-muted-foreground text-sm max-w-sm mb-8">
              Ask about your schedule, campus events, deadlines, or get study recommendations.
            </p>
            <Button 
              size="lg" 
              onClick={handleCreateSession}
              disabled={createSession.isPending}
              className="rounded-full px-8"
            >
              Start a Conversation
            </Button>
          </div>
        ) : (
          <div className="space-y-3">
            {sessions.map((session) => (
              <Link key={session.id} href={`/chat/${session.id}`}>
                <Card className="group hover:border-primary/40 transition-colors cursor-pointer border-transparent bg-secondary/30 hover:bg-secondary/50 shadow-none">
                  <CardContent className="p-4 flex items-center gap-4">
                    <div className="w-10 h-10 rounded-full bg-primary/10 flex flex-col items-center justify-center shrink-0 group-hover:bg-primary group-hover:text-primary-foreground text-primary transition-colors">
                      <MessageSquare className="w-5 h-5" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex justify-between items-center mb-1">
                        <h3 className="font-semibold text-foreground truncate pr-4">{session.title}</h3>
                        <span className="text-xs text-muted-foreground whitespace-nowrap">
                          {formatDistanceToNow(new Date(session.updatedAt), { addSuffix: true })}
                        </span>
                      </div>
                      <p className="text-sm text-muted-foreground truncate">
                        {session.lastMessage || "No messages yet"}
                      </p>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="opacity-0 group-hover:opacity-100 text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-all -mr-2"
                        onClick={(e) => handleDelete(e, session.id)}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                      <ChevronRight className="w-5 h-5 text-muted-foreground/50 group-hover:text-foreground transition-colors" />
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        )}
      </main>
    </div>
  )
}
