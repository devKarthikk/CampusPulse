import * as React from "react"
import { 
  useGetHostelInfo, 
  getGetHostelInfoQueryKey,
  useGetMessMenu,
  getGetMessMenuQueryKey,
  useListLeaveRequests,
  getListLeaveRequestsQueryKey,
  useListComplaints,
  getListComplaintsQueryKey,
  useListEmergencyContacts,
  getListEmergencyContactsQueryKey,
  useSubmitLeaveRequest,
  useSubmitComplaint
} from "@workspace/api-client-react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Skeleton } from "@/components/ui/skeleton"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Home, Coffee, Plane, AlertTriangle, Phone, CheckCircle2, Clock, XCircle, Plus, Info } from "lucide-react"
import { format } from "date-fns"
import { useQueryClient } from "@tanstack/react-query"
import { useToast } from "@/hooks/use-toast"

export default function Hostel() {
  return (
    <div className="flex flex-col min-h-full">
      <header className="sticky top-0 z-30 bg-background/80 backdrop-blur-xl border-b px-4 py-4 md:px-8">
        <h1 className="text-2xl font-bold font-heading mb-1">Hostel Management</h1>
        <p className="text-sm text-muted-foreground">Manage your stay, meals, and requests</p>
      </header>

      <main className="flex-1 p-4 md:p-8 max-w-5xl mx-auto w-full">
        <Tabs defaultValue="info" className="w-full">
          <div className="overflow-x-auto pb-4 scrollbar-hide">
            <TabsList className="w-max inline-flex h-12 bg-secondary/50 rounded-xl p-1 gap-1">
              <TabsTrigger value="info" className="rounded-lg px-4 gap-2">
                <Home className="w-4 h-4" /> <span className="hidden sm:inline">Overview</span>
              </TabsTrigger>
              <TabsTrigger value="mess" className="rounded-lg px-4 gap-2">
                <Coffee className="w-4 h-4" /> <span className="hidden sm:inline">Mess Menu</span>
              </TabsTrigger>
              <TabsTrigger value="leave" className="rounded-lg px-4 gap-2">
                <Plane className="w-4 h-4" /> <span className="hidden sm:inline">Leave</span>
              </TabsTrigger>
              <TabsTrigger value="complaints" className="rounded-lg px-4 gap-2">
                <AlertTriangle className="w-4 h-4" /> <span className="hidden sm:inline">Complaints</span>
              </TabsTrigger>
              <TabsTrigger value="emergency" className="rounded-lg px-4 gap-2">
                <Phone className="w-4 h-4" /> <span className="hidden sm:inline">Emergency</span>
              </TabsTrigger>
            </TabsList>
          </div>
          
          <TabsContent value="info" className="m-0 focus-visible:outline-none">
            <InfoTab />
          </TabsContent>
          <TabsContent value="mess" className="m-0 focus-visible:outline-none">
            <MessTab />
          </TabsContent>
          <TabsContent value="leave" className="m-0 focus-visible:outline-none">
            <LeaveTab />
          </TabsContent>
          <TabsContent value="complaints" className="m-0 focus-visible:outline-none">
            <ComplaintsTab />
          </TabsContent>
          <TabsContent value="emergency" className="m-0 focus-visible:outline-none">
            <EmergencyTab />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}

function InfoTab() {
  const { data, isLoading } = useGetHostelInfo({ query: { queryKey: getGetHostelInfoQueryKey() } })

  if (isLoading) return <div className="space-y-4">{Array(3).fill(0).map((_,i) => <Skeleton key={i} className="h-40 rounded-2xl w-full" />)}</div>
  if (!data) return null

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-br from-primary/10 to-accent/5 border-none shadow-sm">
        <CardContent className="p-6 md:p-8 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <Badge className="mb-2 bg-primary/20 text-primary hover:bg-primary/20 border-none shadow-none">Room Details</Badge>
            <h2 className="text-3xl font-bold font-heading">{data.hostelName}</h2>
            <p className="text-2xl font-light text-muted-foreground mt-1">Room {data.roomNumber}</p>
          </div>
          <div className="bg-background/80 backdrop-blur p-4 rounded-xl shadow-sm border border-border/50">
            <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2">Warden Contact</p>
            <p className="font-medium flex items-center gap-2 mb-1"><UserIcon className="w-4 h-4 text-primary" /> {data.warden}</p>
            <p className="font-medium flex items-center gap-2"><Phone className="w-4 h-4 text-primary" /> {data.wardenPhone}</p>
          </div>
        </CardContent>
      </Card>

      <div className="grid md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2"><Clock className="w-5 h-5 text-primary" /> Timings & Rules</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex gap-4">
              <div className="flex-1 bg-secondary/50 rounded-xl p-3 text-center">
                <p className="text-xs text-muted-foreground font-medium mb-1">Check In</p>
                <p className="font-bold text-foreground">{data.checkInTime}</p>
              </div>
              <div className="flex-1 bg-secondary/50 rounded-xl p-3 text-center">
                <p className="text-xs text-muted-foreground font-medium mb-1">Check Out</p>
                <p className="font-bold text-foreground">{data.checkOutTime}</p>
              </div>
            </div>
            
            <div className="pt-4 border-t space-y-2">
              <p className="text-sm font-semibold mb-3">Important Guidelines</p>
              {data.rules.map((rule, i) => (
                <div key={i} className="flex gap-2 items-start text-sm">
                  <div className="w-1.5 h-1.5 rounded-full bg-primary mt-1.5 shrink-0" />
                  <span className="text-muted-foreground">{rule}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2"><SparklesIcon className="w-5 h-5 text-primary" /> Facilities</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {data.facilities.map((fac, i) => (
                <Badge key={i} variant="secondary" className="px-3 py-1.5 text-sm font-medium bg-secondary text-foreground">
                  {fac}
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

function MessTab() {
  const days = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"]
  const currentDay = format(new Date(), "EEEE").toLowerCase()
  const [day, setDay] = React.useState(days.includes(currentDay) ? currentDay : "monday")
  
  const { data, isLoading } = useGetMessMenu({ day }, { query: { queryKey: getGetMessMenuQueryKey({ day }) } })

  return (
    <div className="space-y-6">
      <div className="flex overflow-x-auto gap-2 pb-2 scrollbar-hide">
        {days.map(d => (
          <Button 
            key={d} 
            variant={day === d ? "default" : "outline"} 
            size="sm"
            onClick={() => setDay(d)}
            className="capitalize rounded-full"
          >
            {d}
          </Button>
        ))}
      </div>

      {isLoading ? (
        <Skeleton className="h-[400px] w-full rounded-2xl" />
      ) : data && data[0] ? (
        <div className="grid md:grid-cols-2 gap-4">
          <MealCard title="Breakfast" items={data[0].breakfast ?? []} icon={Coffee} time="07:30 AM - 09:30 AM" />
          <MealCard title="Lunch" items={data[0].lunch ?? []} icon={SunIcon} time="12:30 PM - 02:30 PM" />
          <MealCard title="Snacks" items={data[0].snacks ?? []} icon={CookieIcon} time="05:00 PM - 06:30 PM" />
          <MealCard title="Dinner" items={data[0].dinner ?? []} icon={MoonIcon} time="08:00 PM - 10:00 PM" />
        </div>
      ) : (
        <div className="text-center py-10 text-muted-foreground">Menu not available for this day</div>
      )}
    </div>
  )
}

function MealCard({ title, items, icon: Icon, time }: { title: string, items: string[], icon: any, time: string }) {
  return (
    <Card className="hover:border-primary/30 transition-colors">
      <CardHeader className="pb-3 flex flex-row items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="p-2 rounded-lg bg-primary/10">
            <Icon className="w-5 h-5 text-primary" />
          </div>
          <CardTitle className="text-lg">{title}</CardTitle>
        </div>
        <Badge variant="secondary" className="font-normal text-xs">{time}</Badge>
      </CardHeader>
      <CardContent>
        <ul className="space-y-2">
          {items.map((item, i) => (
            <li key={i} className="text-sm font-medium text-foreground border-b border-border/50 pb-2 last:border-0">{item}</li>
          ))}
        </ul>
      </CardContent>
    </Card>
  )
}

function LeaveTab() {
  const { data: leaves, isLoading } = useListLeaveRequests({ query: { queryKey: getListLeaveRequestsQueryKey() } })
  const submitLeave = useSubmitLeaveRequest()
  const queryClient = useQueryClient()
  const { toast } = useToast()
  const [isFormOpen, setIsFormOpen] = React.useState(false)

  const handleCreate = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    const formData = new FormData(e.currentTarget)
    submitLeave.mutate({
      data: {
        fromDate: formData.get("fromDate") as string,
        toDate: formData.get("toDate") as string,
        reason: formData.get("reason") as string,
      }
    }, {
      onSuccess: () => {
        toast({ title: "Leave request submitted" })
        setIsFormOpen(false)
        queryClient.invalidateQueries({ queryKey: getListLeaveRequestsQueryKey() })
      }
    })
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="font-heading font-bold text-xl">Leave Requests</h3>
        <Button onClick={() => setIsFormOpen(!isFormOpen)} size="sm" className="rounded-full">
          {isFormOpen ? "Cancel" : <><Plus className="w-4 h-4 mr-1" /> New Request</>}
        </Button>
      </div>

      {isFormOpen && (
        <Card className="border-primary/20 shadow-md">
          <CardHeader>
            <CardTitle className="text-lg">Apply for Leave</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleCreate} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-sm font-medium text-muted-foreground">From Date</label>
                  <Input type="date" name="fromDate" required />
                </div>
                <div className="space-y-1.5">
                  <label className="text-sm font-medium text-muted-foreground">To Date</label>
                  <Input type="date" name="toDate" required />
                </div>
              </div>
              <div className="space-y-1.5">
                <label className="text-sm font-medium text-muted-foreground">Reason</label>
                <Textarea name="reason" placeholder="Detailed reason for leave..." required />
              </div>
              <div className="flex justify-end pt-2">
                <Button type="submit" disabled={submitLeave.isPending}>
                  {submitLeave.isPending ? "Submitting..." : "Submit Request"}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      {isLoading ? (
        <div className="space-y-3">{Array(3).fill(0).map((_,i) => <Skeleton key={i} className="h-24 w-full rounded-xl" />)}</div>
      ) : leaves?.length === 0 ? (
        <div className="text-center py-10 text-muted-foreground">No leave requests found</div>
      ) : (
        <div className="space-y-3">
          {leaves?.map((leave) => (
            <Card key={leave.id}>
              <CardContent className="p-4 flex items-center justify-between gap-4">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <StatusBadge status={leave.status} />
                    <span className="text-xs text-muted-foreground">
                      Applied on {format(new Date(leave.submittedAt), "MMM d")}
                    </span>
                  </div>
                  <p className="font-medium text-sm">
                    {format(new Date(leave.fromDate), "MMM d, yyyy")} - {format(new Date(leave.toDate), "MMM d, yyyy")}
                  </p>
                  <p className="text-sm text-muted-foreground mt-1 line-clamp-1">{leave.reason}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}

function ComplaintsTab() {
  const { data: complaints, isLoading } = useListComplaints({ query: { queryKey: getListComplaintsQueryKey() } })
  const submitComplaint = useSubmitComplaint()
  const queryClient = useQueryClient()
  const { toast } = useToast()
  const [isFormOpen, setIsFormOpen] = React.useState(false)

  const handleCreate = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    const formData = new FormData(e.currentTarget)
    submitComplaint.mutate({
      data: {
        title: formData.get("title") as string,
        category: formData.get("category") as string,
        description: formData.get("description") as string,
      }
    }, {
      onSuccess: () => {
        toast({ title: "Complaint registered" })
        setIsFormOpen(false)
        queryClient.invalidateQueries({ queryKey: getListComplaintsQueryKey() })
      }
    })
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="font-heading font-bold text-xl">Complaints</h3>
        <Button onClick={() => setIsFormOpen(!isFormOpen)} size="sm" className="rounded-full">
          {isFormOpen ? "Cancel" : <><Plus className="w-4 h-4 mr-1" /> New Complaint</>}
        </Button>
      </div>

      {isFormOpen && (
        <Card className="border-primary/20 shadow-md">
          <CardHeader>
            <CardTitle className="text-lg">Register Complaint</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleCreate} className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-sm font-medium text-muted-foreground">Title</label>
                <Input name="title" placeholder="Brief summary of issue" required />
              </div>
              <div className="space-y-1.5">
                <label className="text-sm font-medium text-muted-foreground">Category</label>
                <select 
                  name="category" 
                  className="flex h-10 w-full rounded-lg border border-input bg-background px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                  required
                >
                  <option value="electrical">Electrical</option>
                  <option value="plumbing">Plumbing</option>
                  <option value="cleaning">Cleaning</option>
                  <option value="internet">Internet/Wi-Fi</option>
                  <option value="other">Other</option>
                </select>
              </div>
              <div className="space-y-1.5">
                <label className="text-sm font-medium text-muted-foreground">Description</label>
                <Textarea name="description" placeholder="Provide details..." required />
              </div>
              <div className="flex justify-end pt-2">
                <Button type="submit" disabled={submitComplaint.isPending}>
                  {submitComplaint.isPending ? "Submitting..." : "Submit"}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      {isLoading ? (
        <div className="space-y-3">{Array(3).fill(0).map((_,i) => <Skeleton key={i} className="h-24 w-full rounded-xl" />)}</div>
      ) : complaints?.length === 0 ? (
        <div className="text-center py-10 text-muted-foreground">No complaints filed</div>
      ) : (
        <div className="space-y-3">
          {complaints?.map((comp) => (
            <Card key={comp.id}>
              <CardContent className="p-4">
                <div className="flex justify-between items-start mb-2">
                  <Badge variant="outline" className="capitalize text-xs bg-secondary/30">{comp.category}</Badge>
                  <StatusBadge status={comp.status} />
                </div>
                <h4 className="font-semibold text-foreground mb-1">{comp.title}</h4>
                <p className="text-sm text-muted-foreground line-clamp-2 mb-2">{comp.description}</p>
                <p className="text-xs text-muted-foreground flex items-center gap-1">
                  <Clock className="w-3 h-3" /> Filed on {format(new Date(comp.submittedAt), "MMM d, yyyy")}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}

function EmergencyTab() {
  const { data, isLoading } = useListEmergencyContacts({ query: { queryKey: getListEmergencyContactsQueryKey() } })

  if (isLoading) return <div className="space-y-4">{Array(4).fill(0).map((_,i) => <Skeleton key={i} className="h-20 rounded-2xl w-full" />)}</div>

  return (
    <div className="space-y-4">
      {data?.map((contact) => (
        <Card key={contact.id} className="border-l-4 border-l-destructive overflow-hidden">
          <CardContent className="p-4 flex items-center justify-between">
            <div>
              <h4 className="font-bold text-lg text-foreground">{contact.name}</h4>
              <p className="text-sm font-medium text-muted-foreground capitalize">{contact.role}</p>
              <p className="text-xs text-muted-foreground mt-1">Available: {contact.available}</p>
            </div>
            <a href={`tel:${contact.phone}`}>
              <Button size="icon" className="w-12 h-12 rounded-full bg-destructive/10 text-destructive hover:bg-destructive hover:text-destructive-foreground">
                <Phone className="w-5 h-5" />
              </Button>
            </a>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}

function StatusBadge({ status }: { status: string }) {
  if (status === 'approved' || status === 'resolved') {
    return <Badge className="bg-green-500 hover:bg-green-600 border-none px-2 py-0.5"><CheckCircle2 className="w-3 h-3 mr-1" /> <span className="capitalize">{status}</span></Badge>
  }
  if (status === 'rejected') {
    return <Badge variant="destructive" className="border-none px-2 py-0.5"><XCircle className="w-3 h-3 mr-1" /> <span className="capitalize">{status}</span></Badge>
  }
  return <Badge variant="secondary" className="bg-yellow-500/20 text-yellow-700 dark:text-yellow-400 hover:bg-yellow-500/30 border-none px-2 py-0.5"><Clock className="w-3 h-3 mr-1" /> <span className="capitalize">{status.replace('_', ' ')}</span></Badge>
}

// Icons
function UserIcon(props: any) { return <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinelinejoin="round"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg> }
function SparklesIcon(props: any) { return <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinelinejoin="round"><path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z"/><path d="M5 3v4"/><path d="M19 17v4"/><path d="M3 5h4"/><path d="M17 19h4"/></svg> }
function SunIcon(props: any) { return <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinelinejoin="round"><circle cx="12" cy="12" r="4"/><path d="M12 2v2"/><path d="M12 20v2"/><path d="m4.93 4.93 1.41 1.41"/><path d="m17.66 17.66 1.41 1.41"/><path d="M2 12h2"/><path d="M20 12h2"/><path d="m6.34 17.66-1.41 1.41"/><path d="m19.07 4.93-1.41 1.41"/></svg> }
function MoonIcon(props: any) { return <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinelinejoin="round"><path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"/></svg> }
function CookieIcon(props: any) { return <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinelinejoin="round"><path d="M12 2a10 10 0 1 0 10 10 4 4 0 0 1-5-5 4 4 0 0 1-5-5"/><path d="M8.5 8.5v.01"/><path d="M16 15.5v.01"/><path d="M12 12v.01"/><path d="M11 17v.01"/><path d="M7 14v.01"/></svg> }
