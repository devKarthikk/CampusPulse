import * as React from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Skeleton } from "@/components/ui/skeleton"
import {
  Brain, BookOpen, CalendarClock, ClipboardList, Sparkles,
  TrendingUp, AlertTriangle, CheckCircle2, Clock, RefreshCw
} from "lucide-react"

// ─── Types ────────────────────────────────────────────────────────────────────

interface SubjectAttendance {
  subject: string; attended: number; total: number; percentage: number;
}
interface Exam {
  subject: string; date: string; type: string; syllabus?: string;
}
interface Assignment {
  subject: string; title: string; deadline: string;
  status: "pending" | "submitted" | "overdue"; weightage?: string;
}
interface WellnessData {
  studentName: string; department: string; year: number; semester: number;
  cgpa: number; overallAttendancePercentage: number;
  subjectAttendance: SubjectAttendance[];
  upcomingExams: Exam[]; assignments: Assignment[];
  semesterProgress: number; creditsCompleted: number; creditsRequired: number;
  backlogs: number; lastUpdated: string;
}

// ─── API helpers ──────────────────────────────────────────────────────────────

const base = import.meta.env.BASE_URL.replace(/\/$/, "")

async function fetchWellnessData(): Promise<WellnessData> {
  const r = await fetch(`${base}/api/wellness/data`)
  if (!r.ok) throw new Error("Failed to fetch wellness data")
  return r.json()
}

async function fetchWellnessAnalysis(): Promise<string> {
  const r = await fetch(`${base}/api/wellness/analysis`, { method: "POST" })
  if (!r.ok) throw new Error("Failed to generate analysis")
  const json = await r.json()
  return json.analysis as string
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function daysUntil(dateStr: string) {
  const diff = new Date(dateStr).getTime() - Date.now()
  return Math.round(diff / 86_400_000)
}

function formatDate(dateStr: string) {
  return new Date(dateStr).toLocaleDateString("en-IN", {
    day: "numeric", month: "short", year: "numeric",
  })
}

function attendanceColor(pct: number) {
  if (pct >= 85) return "text-green-600"
  if (pct >= 75) return "text-yellow-600"
  return "text-destructive"
}

function attendanceBg(pct: number) {
  if (pct >= 85) return "bg-green-500"
  if (pct >= 75) return "bg-yellow-500"
  return "bg-destructive"
}

// ─── Markdown renderer (lightweight, no deps) ─────────────────────────────────

function MarkdownBlock({ text }: { text: string }) {
  const lines = text.split("\n")
  const elements: React.ReactNode[] = []
  let i = 0

  const inlineFormat = (s: string) => {
    // bold, inline code
    const parts = s.split(/(\*\*[^*]+\*\*|`[^`]+`)/g)
    return parts.map((p, idx) => {
      if (p.startsWith("**") && p.endsWith("**"))
        return <strong key={idx}>{p.slice(2, -2)}</strong>
      if (p.startsWith("`") && p.endsWith("`"))
        return <code key={idx} className="bg-muted px-1 py-0.5 rounded text-xs font-mono">{p.slice(1, -1)}</code>
      return p
    })
  }

  while (i < lines.length) {
    const line = lines[i]
    if (line.startsWith("# ")) {
      elements.push(<h1 key={i} className="text-2xl font-bold font-heading mt-6 mb-3 text-foreground">{line.slice(2)}</h1>)
    } else if (line.startsWith("## ")) {
      elements.push(<h2 key={i} className="text-lg font-semibold font-heading mt-5 mb-2 text-foreground border-b border-border pb-1">{line.slice(3)}</h2>)
    } else if (line.startsWith("### ")) {
      elements.push(<h3 key={i} className="text-base font-semibold mt-4 mb-1 text-foreground">{line.slice(4)}</h3>)
    } else if (/^[-*] /.test(line)) {
      const listItems: React.ReactNode[] = []
      while (i < lines.length && /^[-*] /.test(lines[i])) {
        listItems.push(<li key={i} className="text-sm leading-relaxed text-foreground/85">{inlineFormat(lines[i].slice(2))}</li>)
        i++
      }
      elements.push(<ul key={`ul-${i}`} className="list-disc list-inside space-y-1 mb-3 ml-2">{listItems}</ul>)
      continue
    } else if (/^\d+\. /.test(line)) {
      const listItems: React.ReactNode[] = []
      while (i < lines.length && /^\d+\. /.test(lines[i])) {
        const content = lines[i].replace(/^\d+\. /, "")
        listItems.push(<li key={i} className="text-sm leading-relaxed text-foreground/85">{inlineFormat(content)}</li>)
        i++
      }
      elements.push(<ol key={`ol-${i}`} className="list-decimal list-inside space-y-1 mb-3 ml-2">{listItems}</ol>)
      continue
    } else if (line.trim() === "---") {
      elements.push(<hr key={i} className="my-4 border-border" />)
    } else if (line.trim() !== "") {
      elements.push(<p key={i} className="text-sm leading-relaxed text-foreground/85 mb-2">{inlineFormat(line)}</p>)
    }
    i++
  }

  return <div className="space-y-1">{elements}</div>
}

// ─── Sub-components ───────────────────────────────────────────────────────────

function AttendanceCard({ data }: { data: SubjectAttendance[] }) {
  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-base flex items-center gap-2">
          <BookOpen className="w-4 h-4 text-primary" /> Subject Attendance
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {data.map((s) => (
          <div key={s.subject}>
            <div className="flex justify-between items-center mb-1">
              <span className="text-sm font-medium truncate max-w-[70%]">{s.subject}</span>
              <span className={`text-sm font-bold ${attendanceColor(s.percentage)}`}>
                {s.percentage.toFixed(1)}%
              </span>
            </div>
            <div className="flex items-center gap-2">
              <div className="flex-1 h-2 bg-secondary rounded-full overflow-hidden">
                <div
                  className={`h-full rounded-full transition-all ${attendanceBg(s.percentage)}`}
                  style={{ width: `${Math.min(s.percentage, 100)}%` }}
                />
              </div>
              <span className="text-xs text-muted-foreground shrink-0">{s.attended}/{s.total}</span>
            </div>
            {s.percentage < 75 && (
              <p className="text-xs text-destructive mt-1 flex items-center gap-1">
                <AlertTriangle className="w-3 h-3" />
                {Math.ceil((0.75 * s.total - s.attended) / 0.25)} more classes needed to reach 75%
              </p>
            )}
          </div>
        ))}
      </CardContent>
    </Card>
  )
}

function ExamsCard({ exams }: { exams: Exam[] }) {
  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-base flex items-center gap-2">
          <CalendarClock className="w-4 h-4 text-primary" /> Upcoming Exams
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {exams.length === 0 ? (
          <p className="text-sm text-muted-foreground">No exams scheduled.</p>
        ) : exams.map((e, i) => {
          const days = daysUntil(e.date)
          const urgent = days <= 5
          return (
            <div key={i} className="flex items-start justify-between gap-3 pb-3 border-b border-border/50 last:border-0 last:pb-0">
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">{e.subject}</p>
                {e.syllabus && <p className="text-xs text-muted-foreground mt-0.5 line-clamp-1">{e.syllabus}</p>}
                <p className="text-xs text-muted-foreground mt-0.5">{formatDate(e.date)}</p>
              </div>
              <div className="shrink-0 text-right">
                <Badge variant={urgent ? "destructive" : "secondary"} className="text-xs mb-1">
                  {e.type}
                </Badge>
                <p className={`text-xs font-semibold ${urgent ? "text-destructive" : "text-muted-foreground"}`}>
                  {days === 0 ? "Today" : days === 1 ? "Tomorrow" : `${days}d`}
                </p>
              </div>
            </div>
          )
        })}
      </CardContent>
    </Card>
  )
}

function AssignmentsCard({ assignments }: { assignments: Assignment[] }) {
  const pending = assignments.filter(a => a.status === "pending")
  const submitted = assignments.filter(a => a.status === "submitted")
  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-base flex items-center gap-2">
          <ClipboardList className="w-4 h-4 text-primary" /> Assignments
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex gap-3 mb-2">
          <div className="flex-1 rounded-xl bg-destructive/10 p-3 text-center">
            <p className="text-2xl font-bold text-destructive">{pending.length}</p>
            <p className="text-xs text-muted-foreground">Pending</p>
          </div>
          <div className="flex-1 rounded-xl bg-green-500/10 p-3 text-center">
            <p className="text-2xl font-bold text-green-600">{submitted.length}</p>
            <p className="text-xs text-muted-foreground">Submitted</p>
          </div>
        </div>
        {pending.map((a, i) => {
          const days = daysUntil(a.deadline)
          return (
            <div key={i} className="flex items-start justify-between gap-2 pb-2 border-b border-border/50 last:border-0">
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium line-clamp-1">{a.title}</p>
                <p className="text-xs text-muted-foreground">{a.subject}</p>
                {a.weightage && <p className="text-xs text-muted-foreground">{a.weightage}</p>}
              </div>
              <div className="shrink-0 text-right">
                <Badge variant={days <= 2 ? "destructive" : "outline"} className="text-xs">
                  <Clock className="w-2.5 h-2.5 mr-1" />
                  {days <= 0 ? "Overdue" : days === 1 ? "Tomorrow" : `${days}d`}
                </Badge>
              </div>
            </div>
          )
        })}
        {submitted.length > 0 && (
          <p className="text-xs text-muted-foreground flex items-center gap-1">
            <CheckCircle2 className="w-3.5 h-3.5 text-green-600" />
            {submitted.length} assignment{submitted.length > 1 ? "s" : ""} submitted this semester
          </p>
        )}
      </CardContent>
    </Card>
  )
}

// ─── Main Page ────────────────────────────────────────────────────────────────

export default function AcademicWellness() {
  const [data, setData] = React.useState<WellnessData | null>(null)
  const [dataLoading, setDataLoading] = React.useState(true)
  const [dataError, setDataError] = React.useState<string | null>(null)

  const [analysis, setAnalysis] = React.useState<string | null>(null)
  const [analysisLoading, setAnalysisLoading] = React.useState(false)
  const [analysisError, setAnalysisError] = React.useState<string | null>(null)

  React.useEffect(() => {
    fetchWellnessData()
      .then(setData)
      .catch(e => setDataError(e.message))
      .finally(() => setDataLoading(false))
  }, [])

  const handleGenerateAnalysis = async () => {
    setAnalysisLoading(true)
    setAnalysisError(null)
    try {
      const result = await fetchWellnessAnalysis()
      setAnalysis(result)
    } catch (e: unknown) {
      setAnalysisError(e instanceof Error ? e.message : "Failed to generate analysis.")
    } finally {
      setAnalysisLoading(false)
    }
  }

  if (dataLoading) {
    return (
      <div className="p-4 md:p-8 space-y-6 max-w-4xl mx-auto">
        <Skeleton className="h-10 w-64" />
        <div className="grid md:grid-cols-3 gap-4">
          {[...Array(3)].map((_, i) => <Skeleton key={i} className="h-32 rounded-2xl" />)}
        </div>
        <Skeleton className="h-64 rounded-2xl" />
        <Skeleton className="h-48 rounded-2xl" />
      </div>
    )
  }

  if (dataError || !data) {
    return (
      <div className="flex flex-col items-center justify-center min-h-full p-8 text-center">
        <AlertTriangle className="w-10 h-10 text-destructive mb-3" />
        <p className="text-lg font-semibold">Could not load wellness data</p>
        <p className="text-sm text-muted-foreground">{dataError}</p>
      </div>
    )
  }

  const lowAttendance = data.subjectAttendance.filter(s => s.percentage < 75)
  const urgentExams = data.upcomingExams.filter(e => daysUntil(e.date) <= 7)
  const pendingAssignments = data.assignments.filter(a => a.status === "pending")

  // Simple wellness score heuristic (server does the real one via Gemma 4)
  const attendanceScore = Math.min(data.overallAttendancePercentage / 75, 1) * 30
  const assignmentScore = Math.max(0, 25 - pendingAssignments.length * 5)
  const examPressureScore = Math.max(0, 25 - urgentExams.length * 6)
  const cgpaScore = Math.min(data.cgpa / 10, 1) * 20
  const wellnessScore = Math.round(attendanceScore + assignmentScore + examPressureScore + cgpaScore)
  const stressLevel = wellnessScore >= 70 ? "Low" : wellnessScore >= 50 ? "Moderate" : "High"
  const stressColor = stressLevel === "Low" ? "text-green-600" : stressLevel === "Moderate" ? "text-yellow-600" : "text-destructive"
  const stressBadge = stressLevel === "Low" ? "default" : stressLevel === "Moderate" ? "secondary" : "destructive"

  return (
    <div className="p-4 md:p-8 pb-8 max-w-4xl mx-auto space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold font-heading">Academic Wellness</h1>
        <p className="text-muted-foreground text-sm mt-1">
          Monitor your academic health and get AI-powered insights.
        </p>
      </div>

      {/* Summary stat cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <Card className="text-center p-4">
          <p className="text-3xl font-bold text-primary">{wellnessScore}%</p>
          <p className="text-xs text-muted-foreground mt-1">Wellness Score</p>
        </Card>
        <Card className="text-center p-4">
          <p className={`text-2xl font-bold ${stressColor}`}>{stressLevel}</p>
          <p className="text-xs text-muted-foreground mt-1">Stress Level</p>
        </Card>
        <Card className="text-center p-4">
          <p className="text-3xl font-bold">{data.overallAttendancePercentage}%</p>
          <p className="text-xs text-muted-foreground mt-1">Attendance</p>
        </Card>
        <Card className="text-center p-4">
          <p className="text-3xl font-bold">{data.cgpa}</p>
          <p className="text-xs text-muted-foreground mt-1">CGPA</p>
        </Card>
      </div>

      {/* Alerts */}
      {(lowAttendance.length > 0 || urgentExams.length > 0) && (
        <div className="space-y-2">
          {lowAttendance.length > 0 && (
            <div className="flex items-start gap-3 rounded-xl bg-destructive/10 border border-destructive/20 p-3">
              <AlertTriangle className="w-4 h-4 text-destructive mt-0.5 shrink-0" />
              <div>
                <p className="text-sm font-semibold text-destructive">Attendance Warning</p>
                <p className="text-xs text-foreground/70 mt-0.5">
                  {lowAttendance.map(s => s.subject).join(", ")} {lowAttendance.length === 1 ? "is" : "are"} below 75%. Attend all upcoming classes.
                </p>
              </div>
            </div>
          )}
          {urgentExams.length > 0 && (
            <div className="flex items-start gap-3 rounded-xl bg-yellow-500/10 border border-yellow-500/20 p-3">
              <CalendarClock className="w-4 h-4 text-yellow-600 mt-0.5 shrink-0" />
              <div>
                <p className="text-sm font-semibold text-yellow-700 dark:text-yellow-500">Exams This Week</p>
                <p className="text-xs text-foreground/70 mt-0.5">
                  {urgentExams.map(e => e.subject).join(", ")} {urgentExams.length === 1 ? "exam is" : "exams are"} within 7 days.
                </p>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Semester progress */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-primary" /> Semester Progress
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex justify-between text-sm mb-1">
            <span className="text-muted-foreground">Semester {data.semester} Progress</span>
            <span className="font-semibold">{data.semesterProgress}%</span>
          </div>
          <Progress value={data.semesterProgress} className="h-2" />
          <div className="flex gap-4 text-xs text-muted-foreground pt-1">
            <span>Credits: {data.creditsCompleted}/{data.creditsRequired}</span>
            <span>Year {data.year}, Semester {data.semester}</span>
            {data.backlogs > 0 && <span className="text-destructive">Backlogs: {data.backlogs}</span>}
          </div>
        </CardContent>
      </Card>

      {/* Attendance + Exams + Assignments */}
      <div className="grid md:grid-cols-2 gap-4">
        <AttendanceCard data={data.subjectAttendance} />
        <div className="space-y-4">
          <ExamsCard exams={data.upcomingExams} />
          <AssignmentsCard assignments={data.assignments} />
        </div>
      </div>

      {/* AI Analysis */}
      <Card className="border-primary/20 bg-primary/5">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-base flex items-center gap-2">
              <Brain className="w-4 h-4 text-primary" /> AI Wellness Report
              <Badge variant="secondary" className="text-xs font-normal">Gemma 4</Badge>
            </CardTitle>
            {analysis && (
              <Button
                variant="ghost" size="sm"
                onClick={handleGenerateAnalysis}
                disabled={analysisLoading}
                className="text-xs gap-1"
              >
                <RefreshCw className={`w-3 h-3 ${analysisLoading ? "animate-spin" : ""}`} />
                Regenerate
              </Button>
            )}
          </div>
        </CardHeader>
        <CardContent>
          {!analysis && !analysisLoading && (
            <div className="flex flex-col items-center justify-center py-10 text-center gap-4">
              <Sparkles className="w-10 h-10 text-primary/40" />
              <div>
                <p className="font-medium text-sm">Get your personalised wellness analysis</p>
                <p className="text-xs text-muted-foreground mt-1">
                  Gemma 4 will analyse your attendance, exams, and assignments to generate a tailored report.
                </p>
              </div>
              <Button onClick={handleGenerateAnalysis} className="gap-2">
                <Brain className="w-4 h-4" /> Generate AI Analysis
              </Button>
            </div>
          )}

          {analysisLoading && (
            <div className="space-y-3 py-4">
              <div className="flex items-center gap-3 text-sm text-muted-foreground mb-4">
                <Sparkles className="w-4 h-4 text-primary animate-pulse" />
                Gemma 4 is analysing your academic data…
              </div>
              {[...Array(6)].map((_, i) => (
                <Skeleton key={i} className={`h-4 rounded ${i % 3 === 2 ? "w-3/4" : "w-full"}`} />
              ))}
            </div>
          )}

          {analysisError && (
            <div className="flex items-start gap-2 rounded-xl bg-destructive/10 p-3">
              <AlertTriangle className="w-4 h-4 text-destructive mt-0.5 shrink-0" />
              <div>
                <p className="text-sm font-semibold text-destructive">Analysis failed</p>
                <p className="text-xs text-foreground/70">{analysisError}</p>
                <Button variant="outline" size="sm" className="mt-2 text-xs" onClick={handleGenerateAnalysis}>
                  Try Again
                </Button>
              </div>
            </div>
          )}

          {analysis && !analysisLoading && (
            <div className="prose-sm max-w-none">
              <MarkdownBlock text={analysis} />
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
