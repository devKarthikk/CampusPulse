import * as React from "react"
import { 
  useListCareerRoadmaps, 
  getListCareerRoadmapsQueryKey,
  useListCareerResources,
  getListCareerResourcesQueryKey,
  useListSkillRecommendations,
  getListSkillRecommendationsQueryKey
} from "@workspace/api-client-react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Skeleton } from "@/components/ui/skeleton"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area"
import { Compass, BookOpen, Target, ArrowRight, Clock, Star, PlayCircle, FileText } from "lucide-react"

export default function CareerHub() {
  return (
    <div className="flex flex-col min-h-full">
      <header className="sticky top-0 z-30 bg-background/80 backdrop-blur-xl border-b px-4 py-6 md:px-8">
        <h1 className="text-2xl md:text-3xl font-bold font-heading mb-2">Career Hub</h1>
        <p className="text-muted-foreground text-sm">Navigate your professional journey with AI-curated roadmaps and resources.</p>
      </header>

      <main className="flex-1 p-4 md:p-8 max-w-6xl mx-auto w-full">
        <Tabs defaultValue="roadmaps" className="w-full">
          <TabsList className="w-full grid grid-cols-3 mb-8 h-12 bg-secondary/50 rounded-xl p-1">
            <TabsTrigger value="roadmaps" className="rounded-lg font-medium text-xs md:text-sm data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">Roadmaps</TabsTrigger>
            <TabsTrigger value="skills" className="rounded-lg font-medium text-xs md:text-sm data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">Skills</TabsTrigger>
            <TabsTrigger value="resources" className="rounded-lg font-medium text-xs md:text-sm data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">Resources</TabsTrigger>
          </TabsList>
          
          <TabsContent value="roadmaps" className="m-0 focus-visible:outline-none">
            <RoadmapsTab />
          </TabsContent>
          
          <TabsContent value="skills" className="m-0 focus-visible:outline-none">
            <SkillsTab />
          </TabsContent>

          <TabsContent value="resources" className="m-0 focus-visible:outline-none">
            <ResourcesTab />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}

function RoadmapsTab() {
  const { data: roadmaps, isLoading } = useListCareerRoadmaps({ query: { queryKey: getListCareerRoadmapsQueryKey() } })

  if (isLoading) {
    return (
      <div className="grid md:grid-cols-2 gap-6">
        {Array(4).fill(0).map((_, i) => <Skeleton key={i} className="h-64 w-full rounded-2xl" />)}
      </div>
    )
  }

  return (
    <div className="grid md:grid-cols-2 gap-6">
      {roadmaps?.map((roadmap) => (
        <Card key={roadmap.id} className="flex flex-col hover:border-primary/40 transition-colors">
          <CardHeader className="pb-4 border-b">
            <div className="flex justify-between items-start mb-2">
              <Badge className="bg-primary/10 text-primary hover:bg-primary/20 border-none font-medium">{roadmap.domain}</Badge>
              <Badge variant="outline" className="font-medium bg-background text-xs capitalize">{roadmap.difficulty}</Badge>
            </div>
            <CardTitle className="text-xl leading-tight">{roadmap.title}</CardTitle>
            <CardDescription className="text-sm mt-2 line-clamp-2">{roadmap.description}</CardDescription>
          </CardHeader>
          <CardContent className="p-6 flex-1 flex flex-col">
            <div className="flex items-center gap-4 text-sm text-muted-foreground mb-6 font-medium">
              <div className="flex items-center gap-1.5"><Clock className="w-4 h-4 text-foreground/70" /> {roadmap.duration}</div>
              <div className="flex items-center gap-1.5"><Target className="w-4 h-4 text-foreground/70" /> {roadmap.steps.length} Steps</div>
            </div>
            
            <div className="space-y-4 mb-6 flex-1 relative pl-3 border-l-2 border-muted">
              {roadmap.steps.slice(0, 3).map((step, idx) => (
                <div key={idx} className="relative">
                  <div className="absolute -left-[19px] top-1 w-3 h-3 rounded-full bg-background border-2 border-primary" />
                  <p className="font-medium text-sm text-foreground">{step.title}</p>
                </div>
              ))}
              {roadmap.steps.length > 3 && (
                <div className="relative">
                  <div className="absolute -left-[19px] top-1 w-3 h-3 rounded-full bg-background border-2 border-muted" />
                  <p className="font-medium text-sm text-muted-foreground italic">+{roadmap.steps.length - 3} more steps</p>
                </div>
              )}
            </div>
            
            <Button className="w-full group">
              Start Roadmap <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
            </Button>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}

function SkillsTab() {
  const { data: skills, isLoading } = useListSkillRecommendations({ query: { queryKey: getListSkillRecommendationsQueryKey() } })

  if (isLoading) {
    return (
      <div className="space-y-4">
        {Array(3).fill(0).map((_, i) => <Skeleton key={i} className="h-32 w-full rounded-2xl" />)}
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {skills?.map((skill) => (
        <Card key={skill.id} className="relative overflow-hidden border-l-4 border-l-accent">
          <CardContent className="p-5 flex flex-col md:flex-row gap-5 md:items-center">
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-2">
                <Badge variant={skill.priority === 'high' ? 'destructive' : 'secondary'} className="uppercase text-[10px] tracking-wider">
                  {skill.priority} priority
                </Badge>
                <span className="text-xs font-medium text-muted-foreground px-2 py-0.5 bg-secondary/50 rounded-md">{skill.category}</span>
              </div>
              <h3 className="text-lg font-bold font-heading mb-1">{skill.skill}</h3>
              <p className="text-sm text-muted-foreground">{skill.reason}</p>
            </div>
            
            <div className="shrink-0 w-full md:w-auto md:border-l md:pl-5 pt-4 md:pt-0 border-t md:border-t-0">
              <p className="text-xs font-semibold text-foreground mb-3 uppercase tracking-wider">Recommended Resources</p>
              <div className="flex flex-col gap-2">
                {skill.resources.slice(0,2).map((res, i) => (
                  <a key={i} href="#" className="text-sm text-primary hover:underline flex items-center gap-1.5 font-medium">
                    <PlayCircle className="w-3.5 h-3.5" />
                    <span className="truncate max-w-[200px]">{res}</span>
                  </a>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}

function ResourcesTab() {
  const [category, setCategory] = React.useState<string | undefined>()
  const { data: resources, isLoading } = useListCareerResources(
    { category }, 
    { query: { queryKey: getListCareerResourcesQueryKey({ category }) } }
  )

  const categories = ["all", "resume", "interview", "skills", "internship"]

  return (
    <div className="space-y-6">
      <ScrollArea className="w-full whitespace-nowrap pb-4">
        <div className="flex w-max space-x-2 px-1">
          {categories.map((cat) => (
            <Button
              key={cat}
              variant={category === (cat === "all" ? undefined : cat) ? "default" : "secondary"}
              size="sm"
              onClick={() => setCategory(cat === "all" ? undefined : cat)}
              className="rounded-full px-5 capitalize"
            >
              {cat}
            </Button>
          ))}
        </div>
        <ScrollBar orientation="horizontal" className="hidden" />
      </ScrollArea>

      {isLoading ? (
        <div className="grid md:grid-cols-3 gap-4">
          {Array(6).fill(0).map((_, i) => <Skeleton key={i} className="h-48 w-full rounded-2xl" />)}
        </div>
      ) : (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {resources?.map((resource) => (
            <Card key={resource.id} className="group hover:border-primary/40 transition-colors cursor-pointer flex flex-col">
              <CardContent className="p-5 flex-1 flex flex-col">
                <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center mb-4 text-primary group-hover:scale-110 transition-transform">
                  <FileText className="w-5 h-5" />
                </div>
                <h3 className="font-bold text-lg leading-tight mb-2 group-hover:text-primary transition-colors">{resource.title}</h3>
                <p className="text-sm text-muted-foreground mb-4 line-clamp-2 flex-1">{resource.description}</p>
                <div className="flex items-center justify-between mt-auto pt-4 border-t border-border/50">
                  <Badge variant="secondary" className="capitalize text-xs font-normal bg-secondary/50">{resource.category}</Badge>
                  <span className="text-xs font-medium text-muted-foreground flex items-center gap-1">
                    <Clock className="w-3 h-3" /> {resource.readTime} min read
                  </span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
