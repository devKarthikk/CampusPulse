import * as React from "react"
import { 
  useGetChatSession, 
  getGetChatSessionQueryKey,
  useSendMessage
} from "@workspace/api-client-react"
import { useParams, Link } from "wouter"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Skeleton } from "@/components/ui/skeleton"
import { ArrowLeft, Send, Sparkles, User, Info } from "lucide-react"
import { useQueryClient } from "@tanstack/react-query"

export default function AIChatDetail() {
  const { id } = useParams()
  const sessionId = parseInt(id || "0")
  const scrollRef = React.useRef<HTMLDivElement>(null)
  const [input, setInput] = React.useState("")
  
  const { data: session, isLoading } = useGetChatSession(sessionId, {
    query: { enabled: !!sessionId, queryKey: getGetChatSessionQueryKey(sessionId) }
  })

  const sendMessage = useSendMessage()
  const queryClient = useQueryClient()

  React.useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight
    }
  }, [session?.messages, sendMessage.isPending])

  const handleSend = () => {
    if (!input.trim() || !session) return
    
    const messageContent = input.trim()
    setInput("")
    
    sendMessage.mutate(
      { id: sessionId, data: { content: messageContent } },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetChatSessionQueryKey(sessionId) })
        }
      }
    )
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSend()
    }
  }

  if (isLoading) {
    return (
      <div className="flex flex-col h-[100dvh]">
        <header className="border-b px-4 py-4 flex items-center">
          <Skeleton className="w-8 h-8 rounded-full mr-4" />
          <Skeleton className="h-6 w-48" />
        </header>
        <div className="flex-1 p-4 space-y-6">
          <Skeleton className="h-20 w-3/4 rounded-2xl rounded-tl-sm ml-auto" />
          <Skeleton className="h-32 w-3/4 rounded-2xl rounded-tr-sm" />
        </div>
      </div>
    )
  }

  if (!session) {
    return (
      <div className="flex flex-col items-center justify-center min-h-full text-center p-4">
        <h2 className="text-xl font-bold mb-2">Session not found</h2>
        <Button asChild variant="outline">
          <Link href="/chat">Back to Chats</Link>
        </Button>
      </div>
    )
  }

  return (
    <div className="flex flex-col h-[100dvh] bg-background">
      <header className="sticky top-0 z-30 bg-background/95 backdrop-blur-md border-b px-2 md:px-6 py-3 flex items-center gap-3">
        <Button asChild variant="ghost" size="icon" className="shrink-0 rounded-full hover:bg-secondary">
          <Link href="/chat">
            <ArrowLeft className="w-5 h-5" />
          </Link>
        </Button>
        <div className="flex-1 min-w-0">
          <h1 className="font-semibold font-heading truncate text-base md:text-lg">{session.title}</h1>
          <p className="text-xs text-muted-foreground flex items-center gap-1">
            <Sparkles className="w-3 h-3 text-primary" /> AI Assistant
          </p>
        </div>
        <Button variant="ghost" size="icon" className="text-muted-foreground shrink-0 rounded-full">
          <Info className="w-5 h-5" />
        </Button>
      </header>

      <div 
        ref={scrollRef}
        className="flex-1 overflow-y-auto p-4 md:p-8 space-y-6 md:space-y-8 scroll-smooth"
      >
        <div className="max-w-3xl mx-auto space-y-6 md:space-y-8">
          {session.messages.length === 0 && (
            <div className="flex flex-col items-center justify-center py-20 text-center text-muted-foreground">
              <Sparkles className="w-12 h-12 text-primary/40 mb-4" />
              <p>This is the start of your conversation.</p>
            </div>
          )}
          
          {session.messages.map((message) => {
            const isUser = message.role === "user"
            return (
              <div 
                key={message.id} 
                className={`flex gap-3 md:gap-4 ${isUser ? "flex-row-reverse" : "flex-row"}`}
              >
                <div className={`w-8 h-8 md:w-10 md:h-10 rounded-full flex shrink-0 items-center justify-center shadow-sm ${
                  isUser ? "bg-primary text-primary-foreground" : "bg-accent text-accent-foreground"
                }`}>
                  {isUser ? <User className="w-4 h-4 md:w-5 md:h-5" /> : <Sparkles className="w-4 h-4 md:w-5 md:h-5" />}
                </div>
                
                <div className={`flex flex-col max-w-[85%] md:max-w-[75%] ${isUser ? "items-end" : "items-start"}`}>
                  <div 
                    className={`px-4 py-3 md:px-5 md:py-4 shadow-sm leading-relaxed text-sm md:text-base whitespace-pre-wrap ${
                      isUser 
                        ? "bg-primary text-primary-foreground rounded-2xl rounded-tr-sm" 
                        : "bg-secondary text-secondary-foreground rounded-2xl rounded-tl-sm border border-border/50"
                    }`}
                  >
                    {message.content}
                  </div>
                </div>
              </div>
            )
          })}
          
          {sendMessage.isPending && (
            <div className="flex gap-3 md:gap-4 flex-row">
              <div className="w-8 h-8 md:w-10 md:h-10 rounded-full flex shrink-0 items-center justify-center shadow-sm bg-accent text-accent-foreground">
                <Sparkles className="w-4 h-4 md:w-5 md:h-5" />
              </div>
              <div className="bg-secondary text-secondary-foreground px-5 py-4 rounded-2xl rounded-tl-sm w-24 flex items-center justify-center gap-1 border border-border/50">
                <div className="w-2 h-2 bg-muted-foreground/40 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                <div className="w-2 h-2 bg-muted-foreground/40 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                <div className="w-2 h-2 bg-muted-foreground/40 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="p-3 md:p-4 bg-background border-t safe-area-bottom">
        <div className="max-w-3xl mx-auto relative flex items-end gap-2 bg-secondary/50 rounded-3xl border border-border/50 p-2 focus-within:ring-2 focus-within:ring-primary/50 focus-within:bg-background transition-all shadow-sm">
          <Textarea 
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Ask about events, schedules, or campus info..."
            className="min-h-[44px] max-h-32 border-0 bg-transparent focus-visible:ring-0 resize-none py-3 px-4 shadow-none scrollbar-hide text-base"
            rows={1}
          />
          <Button 
            size="icon" 
            onClick={handleSend}
            disabled={!input.trim() || sendMessage.isPending}
            className={`shrink-0 rounded-full w-10 h-10 mb-1 mr-1 transition-all ${
              input.trim() ? "bg-primary text-primary-foreground shadow-md hover:bg-primary/90" : "bg-muted text-muted-foreground"
            }`}
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>
        <p className="text-[10px] text-center text-muted-foreground mt-2 font-medium">
          Campus Pulse AI can make mistakes. Check important deadlines.
        </p>
      </div>
    </div>
  )
}
