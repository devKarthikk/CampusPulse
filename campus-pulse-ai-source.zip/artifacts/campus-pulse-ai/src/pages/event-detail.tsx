import * as React from "react"
import { 
  useGetEvent, 
  getGetEventQueryKey,
  useToggleEventBookmark,
  useRegisterForEvent
} from "@workspace/api-client-react"
import { useParams, Link } from "wouter"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Skeleton } from "@/components/ui/skeleton"
import { ArrowLeft, MapPin, Clock, Calendar as CalendarIcon, Bookmark, Users, Tag, Share2 } from "lucide-react"
import { format } from "date-fns"
import { useQueryClient } from "@tanstack/react-query"
import { useToast } from "@/hooks/use-toast"

export default function EventDetail() {
  const { id } = useParams()
  const eventId = parseInt(id || "0")
  const { toast } = useToast()
  
  const { data: event, isLoading } = useGetEvent(eventId, {
    query: { enabled: !!eventId, queryKey: getGetEventQueryKey(eventId) }
  })

  const toggleBookmark = useToggleEventBookmark()
  const register = useRegisterForEvent()
  const queryClient = useQueryClient()

  const handleBookmark = () => {
    if (!event) return
    toggleBookmark.mutate({ id: eventId }, {
      onSuccess: () => {
        queryClient.setQueryData(getGetEventQueryKey(eventId), (old: any) => 
          old ? { ...old, isBookmarked: !old.isBookmarked } : old
        )
      }
    })
  }

  const handleRegister = () => {
    if (!event) return
    register.mutate({ id: eventId }, {
      onSuccess: (res) => {
        toast({
          title: res.registered ? "Registered successfully" : "Registration cancelled",
          description: res.message
        })
        queryClient.setQueryData(getGetEventQueryKey(eventId), (old: any) => 
          old ? { ...old, isRegistered: res.registered, registeredCount: old.registeredCount + (res.registered ? 1 : -1) } : old
        )
      }
    })
  }

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: event?.title,
        url: window.location.href,
      }).catch(console.error)
    } else {
      navigator.clipboard.writeText(window.location.href)
      toast({ title: "Link copied to clipboard" })
    }
  }

  if (isLoading) {
    return (
      <div className="flex flex-col min-h-full">
        <Skeleton className="h-64 w-full rounded-none" />
        <div className="p-4 md:p-8 max-w-3xl mx-auto w-full -mt-8 relative z-10 space-y-4">
          <Skeleton className="h-32 w-full rounded-2xl" />
          <Skeleton className="h-48 w-full rounded-2xl" />
        </div>
      </div>
    )
  }

  if (!event) {
    return (
      <div className="flex flex-col items-center justify-center min-h-full text-center p-4">
        <h2 className="text-xl font-bold mb-2">Event not found</h2>
        <Button asChild variant="outline">
          <Link href="/events">Back to Events</Link>
        </Button>
      </div>
    )
  }

  const spotsLeft = event.capacity ? event.capacity - event.registeredCount : null
  const isFull = spotsLeft !== null && spotsLeft <= 0

  return (
    <div className="flex flex-col min-h-[100dvh] pb-24 md:pb-8">
      {/* Header Image Area */}
      <div className="relative h-64 md:h-80 w-full bg-muted overflow-hidden">
        {event.imageUrl ? (
          <img src={event.imageUrl} alt={event.title} className="w-full h-full object-cover" />
        ) : (
          <div className="w-full h-full bg-gradient-to-br from-primary/80 to-accent/80" />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-background/90 via-background/20 to-transparent" />
        
        {/* Top bar over image */}
        <div className="absolute top-0 left-0 right-0 p-4 flex justify-between items-center z-10">
          <Button asChild variant="secondary" size="icon" className="rounded-full bg-background/50 backdrop-blur-md border-transparent hover:bg-background/80 text-foreground">
            <Link href="/events">
              <ArrowLeft className="w-5 h-5" />
            </Link>
          </Button>
          
          <div className="flex gap-2">
            <Button onClick={handleShare} variant="secondary" size="icon" className="rounded-full bg-background/50 backdrop-blur-md border-transparent hover:bg-background/80 text-foreground">
              <Share2 className="w-5 h-5" />
            </Button>
            <Button onClick={handleBookmark} variant="secondary" size="icon" className="rounded-full bg-background/50 backdrop-blur-md border-transparent hover:bg-background/80 text-foreground">
              <Bookmark className={`w-5 h-5 ${event.isBookmarked ? 'fill-primary text-primary' : ''}`} />
            </Button>
          </div>
        </div>
      </div>

      <main className="flex-1 px-4 md:px-8 max-w-4xl mx-auto w-full -mt-20 relative z-10 space-y-6">
        {/* Main Info Card */}
        <Card className="shadow-lg border-none">
          <CardContent className="p-6 md:p-8">
            <div className="flex items-center gap-2 mb-4">
              <Badge className="bg-primary/10 text-primary hover:bg-primary/20 border-transparent">
                {event.category}
              </Badge>
              {event.isRegistered && (
                <Badge variant="default" className="bg-green-500 hover:bg-green-600">Registered</Badge>
              )}
            </div>
            
            <h1 className="text-2xl md:text-4xl font-bold font-heading mb-6">{event.title}</h1>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6 mb-6">
              <div className="flex items-center gap-3 p-3 rounded-xl bg-secondary/30">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                  <CalendarIcon className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <p className="text-sm font-medium">{format(new Date(event.date), "EEEE, MMMM d, yyyy")}</p>
                  <p className="text-xs text-muted-foreground">{event.time}</p>
                </div>
              </div>
              
              <div className="flex items-center gap-3 p-3 rounded-xl bg-secondary/30">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                  <MapPin className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <p className="text-sm font-medium line-clamp-1">{event.location}</p>
                  <p className="text-xs text-muted-foreground">Location</p>
                </div>
              </div>
              
              <div className="flex items-center gap-3 p-3 rounded-xl bg-secondary/30">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                  <Users className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <p className="text-sm font-medium">
                    {event.registeredCount} attending
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {spotsLeft !== null ? `${spotsLeft} spots left` : "Unlimited capacity"}
                  </p>
                </div>
              </div>
              
              <div className="flex items-center gap-3 p-3 rounded-xl bg-secondary/30">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                  <div className="w-5 h-5 font-bold font-heading text-primary flex items-center justify-center">O</div>
                </div>
                <div>
                  <p className="text-sm font-medium line-clamp-1">{event.organizer}</p>
                  <p className="text-xs text-muted-foreground">Organizer</p>
                </div>
              </div>
            </div>
            
            <div className="prose prose-sm md:prose-base dark:prose-invert max-w-none">
              <h3 className="text-lg font-semibold font-heading mb-2">About this event</h3>
              <p className="text-muted-foreground leading-relaxed whitespace-pre-wrap">{event.description}</p>
            </div>
            
            {event.tags && event.tags.length > 0 && (
              <div className="mt-8 flex flex-wrap gap-2">
                {event.tags.map(tag => (
                  <Badge key={tag} variant="secondary" className="flex items-center gap-1 font-normal">
                    <Tag className="w-3 h-3" /> {tag}
                  </Badge>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </main>

      {/* Floating Action Bar */}
      <div className="fixed bottom-[72px] md:bottom-0 left-0 right-0 p-4 bg-background/80 backdrop-blur-xl border-t z-40 md:pl-64">
        <div className="max-w-4xl mx-auto flex items-center justify-between gap-4">
          <div className="hidden sm:block">
            <p className="font-semibold text-sm">{event.title}</p>
            <p className="text-xs text-muted-foreground">{format(new Date(event.date), "MMM d")} • {event.time}</p>
          </div>
          
          <Button 
            className="w-full sm:w-auto px-8" 
            size="lg"
            variant={event.isRegistered ? "outline" : "default"}
            disabled={(isFull && !event.isRegistered) || register.isPending}
            onClick={handleRegister}
          >
            {register.isPending ? "Loading..." : 
             event.isRegistered ? "Cancel Registration" : 
             isFull ? "Event Full" : "Register Now"}
          </Button>
        </div>
      </div>
    </div>
  )
}
