import * as React from "react"
import { 
  useGetProfile, 
  getGetProfileQueryKey,
  useUpdateProfile
} from "@workspace/api-client-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Skeleton } from "@/components/ui/skeleton"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { useToast } from "@/hooks/use-toast"
import { Mail, Phone, MapPin, GraduationCap, Github, Linkedin, Award, Target, Settings, Edit3 } from "lucide-react"
import { useQueryClient } from "@tanstack/react-query"
import { useTheme } from "@/hooks/use-theme"

export default function Profile() {
  const { data: profile, isLoading } = useGetProfile({ query: { queryKey: getGetProfileQueryKey() } })
  const updateProfile = useUpdateProfile()
  const queryClient = useQueryClient()
  const { toast } = useToast()
  
  const [isEditing, setIsEditing] = React.useState(false)
  const { theme, setTheme } = useTheme()

  const handleUpdate = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    const formData = new FormData(e.currentTarget)
    
    // Parse skills and interests from comma-separated string
    const skillsStr = formData.get("skills") as string
    const interestsStr = formData.get("interests") as string
    
    const skills = skillsStr ? skillsStr.split(',').map(s => s.trim()).filter(Boolean) : []
    const interests = interestsStr ? interestsStr.split(',').map(s => s.trim()).filter(Boolean) : []

    updateProfile.mutate({
      data: {
        name: formData.get("name") as string,
        phone: formData.get("phone") as string,
        bio: formData.get("bio") as string,
        linkedinUrl: formData.get("linkedinUrl") as string,
        githubUrl: formData.get("githubUrl") as string,
        skills,
        interests
      }
    }, {
      onSuccess: () => {
        toast({ title: "Profile updated successfully" })
        setIsEditing(false)
        queryClient.invalidateQueries({ queryKey: getGetProfileQueryKey() })
      }
    })
  }

  if (isLoading) {
    return (
      <div className="p-4 md:p-8 space-y-6 max-w-4xl mx-auto">
        <div className="flex items-center gap-6">
          <Skeleton className="w-24 h-24 rounded-full" />
          <div className="space-y-2 flex-1">
            <Skeleton className="h-8 w-1/3" />
            <Skeleton className="h-4 w-1/4" />
          </div>
        </div>
        <Skeleton className="h-64 w-full rounded-2xl" />
      </div>
    )
  }

  if (!profile) return null

  return (
    <div className="flex flex-col min-h-full">
      <header className="sticky top-0 z-30 bg-background/80 backdrop-blur-xl border-b px-4 py-4 md:px-8 flex justify-between items-center">
        <h1 className="text-2xl font-bold font-heading">Profile</h1>
        <div className="flex gap-2">
          <Button 
            variant="ghost" 
            size="icon" 
            className="rounded-full"
            onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
          >
            <Settings className="w-5 h-5 text-muted-foreground" />
          </Button>
          {!isEditing && (
            <Button onClick={() => setIsEditing(true)} size="sm" className="rounded-full gap-2">
              <Edit3 className="w-4 h-4" /> <span className="hidden sm:inline">Edit Profile</span>
            </Button>
          )}
        </div>
      </header>

      <main className="flex-1 p-4 md:p-8 max-w-4xl mx-auto w-full space-y-6">
        {/* Top Profile Card */}
        <Card className="bg-gradient-to-br from-primary/10 to-accent/5 border-none shadow-sm overflow-hidden relative">
          <div className="absolute top-0 right-0 w-64 h-64 bg-primary/10 rounded-full blur-3xl -mr-20 -mt-20 pointer-events-none" />
          <CardContent className="p-6 md:p-8 flex flex-col md:flex-row items-center gap-6 text-center md:text-left relative z-10">
            <Avatar className="w-24 h-24 md:w-32 md:h-32 border-4 border-background shadow-md">
              <AvatarImage src={profile.avatar || undefined} />
              <AvatarFallback className="bg-primary text-primary-foreground text-3xl font-heading font-bold">
                {profile.name.charAt(0)}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <h2 className="text-3xl font-bold font-heading">{profile.name}</h2>
              <p className="text-lg text-primary font-medium mt-1">{profile.department}</p>
              <div className="flex flex-wrap items-center justify-center md:justify-start gap-4 mt-4 text-sm text-muted-foreground">
                <span className="flex items-center gap-1.5"><GraduationCap className="w-4 h-4" /> Year {profile.year}</span>
                <span className="flex items-center gap-1.5"><Award className="w-4 h-4" /> CGPA: {profile.cgpa}</span>
                <span className="flex items-center gap-1.5"><MapPin className="w-4 h-4" /> ID: {profile.studentId}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {isEditing ? (
          <Card className="border-primary/20 shadow-md">
            <CardHeader>
              <CardTitle>Edit Information</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleUpdate} className="space-y-5">
                <div className="grid md:grid-cols-2 gap-5">
                  <div className="space-y-1.5">
                    <label className="text-sm font-medium">Full Name</label>
                    <Input name="name" defaultValue={profile.name} required />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-sm font-medium">Phone Number</label>
                    <Input name="phone" defaultValue={profile.phone || ""} />
                  </div>
                </div>
                
                <div className="space-y-1.5">
                  <label className="text-sm font-medium">Bio</label>
                  <Textarea name="bio" defaultValue={profile.bio || ""} className="resize-none" rows={3} />
                </div>
                
                <div className="grid md:grid-cols-2 gap-5">
                  <div className="space-y-1.5">
                    <label className="text-sm font-medium flex items-center gap-2"><Github className="w-4 h-4" /> GitHub URL</label>
                    <Input name="githubUrl" defaultValue={profile.githubUrl || ""} placeholder="https://github.com/username" />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-sm font-medium flex items-center gap-2"><Linkedin className="w-4 h-4" /> LinkedIn URL</label>
                    <Input name="linkedinUrl" defaultValue={profile.linkedinUrl || ""} placeholder="https://linkedin.com/in/username" />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-sm font-medium">Skills (comma separated)</label>
                  <Input name="skills" defaultValue={profile.skills?.join(", ")} placeholder="React, Python, Design..." />
                </div>
                
                <div className="space-y-1.5">
                  <label className="text-sm font-medium">Interests (comma separated)</label>
                  <Input name="interests" defaultValue={profile.interests?.join(", ")} placeholder="AI, Web Dev, Music..." />
                </div>

                <div className="flex justify-end gap-2 pt-4 border-t">
                  <Button type="button" variant="ghost" onClick={() => setIsEditing(false)}>Cancel</Button>
                  <Button type="submit" disabled={updateProfile.isPending}>
                    {updateProfile.isPending ? "Saving..." : "Save Changes"}
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        ) : (
          <div className="grid md:grid-cols-3 gap-6">
            <div className="md:col-span-1 space-y-6">
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-base font-semibold">Contact Info</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center gap-3 text-sm">
                    <div className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center shrink-0">
                      <Mail className="w-4 h-4 text-muted-foreground" />
                    </div>
                    <span className="truncate text-foreground font-medium">{profile.email}</span>
                  </div>
                  {profile.phone && (
                    <div className="flex items-center gap-3 text-sm">
                      <div className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center shrink-0">
                        <Phone className="w-4 h-4 text-muted-foreground" />
                      </div>
                      <span className="text-foreground font-medium">{profile.phone}</span>
                    </div>
                  )}
                  {profile.githubUrl && (
                    <a href={profile.githubUrl} target="_blank" rel="noreferrer" className="flex items-center gap-3 text-sm hover:text-primary transition-colors group">
                      <div className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center shrink-0 group-hover:bg-primary/10">
                        <Github className="w-4 h-4 text-muted-foreground group-hover:text-primary" />
                      </div>
                      <span className="truncate font-medium">GitHub Profile</span>
                    </a>
                  )}
                  {profile.linkedinUrl && (
                    <a href={profile.linkedinUrl} target="_blank" rel="noreferrer" className="flex items-center gap-3 text-sm hover:text-primary transition-colors group">
                      <div className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center shrink-0 group-hover:bg-primary/10">
                        <Linkedin className="w-4 h-4 text-muted-foreground group-hover:text-primary" />
                      </div>
                      <span className="truncate font-medium">LinkedIn Profile</span>
                    </a>
                  )}
                </CardContent>
              </Card>
            </div>

            <div className="md:col-span-2 space-y-6">
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-base font-semibold">About</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground leading-relaxed text-sm md:text-base">
                    {profile.bio || "No bio added yet. Edit your profile to add a brief introduction."}
                  </p>
                </CardContent>
              </Card>

              <div className="grid sm:grid-cols-2 gap-6">
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base font-semibold flex items-center gap-2">
                      <Target className="w-4 h-4 text-primary" /> Skills
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {profile.skills && profile.skills.length > 0 ? (
                      <div className="flex flex-wrap gap-2">
                        {profile.skills.map(skill => (
                          <Badge key={skill} variant="secondary" className="bg-primary/10 text-primary hover:bg-primary/20">{skill}</Badge>
                        ))}
                      </div>
                    ) : (
                      <p className="text-sm text-muted-foreground">No skills added.</p>
                    )}
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base font-semibold flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-accent" /> Interests
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {profile.interests && profile.interests.length > 0 ? (
                      <div className="flex flex-wrap gap-2">
                        {profile.interests.map(interest => (
                          <Badge key={interest} variant="outline" className="border-accent/30 text-accent-foreground">{interest}</Badge>
                        ))}
                      </div>
                    ) : (
                      <p className="text-sm text-muted-foreground">No interests added.</p>
                    )}
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  )
}

function Sparkles(props: any) {
  return <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinelinejoin="round"><path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z"/><path d="M5 3v4"/><path d="M19 17v4"/><path d="M3 5h4"/><path d="M17 19h4"/></svg>
}
