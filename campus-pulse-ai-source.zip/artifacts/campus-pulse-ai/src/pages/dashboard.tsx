import * as React from "react"
import { 
  useGetDashboardSummary, 
  useGetDailyQuote, 
  useGetProfile,
  getGetDashboardSummaryQueryKey,
  getGetDailyQuoteQueryKey,
  getGetProfileQueryKey
} from "@workspace/api-client-react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Skeleton } from "@/components/ui/skeleton"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Sparkles, Calendar, Bell, FileText, GraduationCap, ChevronRight, Clock } from "lucide-react"
import { Link } from "wouter"
import { format } from "date-fns"

export default function Dashboard() {
  const { data: profile, isLoading: isProfileLoading } = useGetProfile({ query: { queryKey: getGetProfileQueryKey() } })
  const { data: summary, isLoading: isSummaryLoading } = useGetDashboardSummary({ query: { queryKey: getGetDashboardSummaryQueryKey() } })
  const { data: quote, isLoading: isQuoteLoading } = useGetDailyQuote({ query: { queryKey: getGetDailyQuoteQueryKey() } })

  return (
    <div className="flex flex-col min-h-full">
      {/* Header */}
      <header className="sticky top-0 z-30 bg-background/80 backdrop-blur-xl border-b px-4 py-4 md:px-8 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Avatar className="h-10 w-10 border-2 border-primary/20">
            <AvatarImage src={profile?.avatar || undefined} />
            <AvatarFallback className="bg-primary/10 text-primary font-bold">
              {profile?.name?.charAt(0) || "U"}
            </AvatarFallback>
          </Avatar>
          <div className="flex flex-col">
            <p className="text-xs text-muted-foreground font-medium">Good morning,</p>
            {isProfileLoading ? (
              <Skeleton className="h-5 w-24" />
            ) : (
              <h1 className="text-lg font-bold font-heading leading-tight">{profile?.name || "Student"}</h1>
            )}
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          <Link href="/notifications" className="relative p-2 rounded-full hover:bg-secondary transition-colors">
            <Bell className="w-5 h-5 text-foreground" />
            {summary?.unreadNotifications ? (
              <span className="absolute top-1.5 right-1.5 w-2.5 h-2.5 bg-destructive rounded-full border-2 border-background" />
            ) : null}
          </Link>
          <Link href="/profile" className="p-2 rounded-full hover:bg-secondary transition-colors md:hidden">
            <div className="w-5 h-5 rounded-full bg-primary/20 flex items-center justify-center">
              <span className="w-1.5 h-1.5 rounded-full bg-primary" />
            </div>
          </Link>
        </div>
      </header>

      <main className="flex-1 p-4 md:p-8 space-y-6 max-w-5xl mx-auto w-full">
        {/* Quote Card */}
        <Card className="bg-gradient-to-br from-primary/10 to-accent/5 border-none shadow-sm relative overflow-hidden">
          <div className="absolute -right-12 -top-12 w-32 h-32 bg-primary/20 blur-3xl rounded-full" />
          <CardContent className="p-6">
            <Sparkles className="w-6 h-6 text-primary mb-3" />
            {isQuoteLoading ? (
              <div className="space-y-2">
                <Skeleton className="h-6 w-full" />
                <Skeleton className="h-4 w-1/3" />
              </div>
            ) : (
              <>
                <p className="text-lg font-medium text-foreground mb-2 leading-relaxed">
                  "{quote?.quote || "The beautiful thing about learning is that nobody can take it away from you."}"
                </p>
                <p className="text-sm text-muted-foreground font-medium">— {quote?.author || "B.B. King"}</p>
              </>
            )}
          </CardContent>
        </Card>

        {/* AI Quick Action */}
        <Link href="/chat">
          <div className="group relative w-full rounded-2xl bg-foreground text-background p-5 overflow-hidden cursor-pointer shadow-md hover:shadow-lg transition-all active:scale-[0.98]">
            <div className="absolute inset-0 bg-gradient-to-r from-primary via-accent to-primary opacity-20 group-hover:opacity-30 transition-opacity" />
            <div className="relative flex items-center justify-between z-10">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-background/20 flex items-center justify-center backdrop-blur-md">
                  <Sparkles className="w-6 h-6 text-background" />
                </div>
                <div>
                  <h3 className="font-heading font-bold text-lg">Ask Campus AI</h3>
                  <p className="text-sm text-background/80">Get instant answers about campus, schedules, or courses</p>
                </div>
              </div>
              <ChevronRight className="w-6 h-6 text-background/50 group-hover:text-background transition-colors" />
            </div>
          </div>
        </Link>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <StatCard 
            icon={Calendar} 
            label="Upcoming Events" 
            value={summary?.upcomingEvents} 
            loading={isSummaryLoading}
            href="/events"
          />
          <StatCard 
            icon={GraduationCap} 
            label="Scholarships" 
            value={summary?.activeScholarships} 
            loading={isSummaryLoading}
            href="/scholarships"
          />
          <StatCard 
            icon={FileText} 
            label="Documents" 
            value={summary?.documentsCount} 
            loading={isSummaryLoading}
            href="/documents"
          />
          <StatCard 
            icon={Bell} 
            label="Unread" 
            value={summary?.unreadNotifications} 
            loading={isSummaryLoading}
            href="/notifications"
          />
        </div>

        {/* Deadlines & Events Layout */}
        <div className="grid md:grid-cols-2 gap-6">
          {/* Upcoming Deadlines */}
          <Card>
            <CardHeader className="pb-3 flex flex-row items-center justify-between">
              <CardTitle className="text-lg">Upcoming Deadlines</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {isSummaryLoading ? (
                Array(3).fill(0).map((_, i) => <Skeleton key={i} className="h-14 w-full rounded-xl" />)
              ) : summary?.upcomingDeadlines && summary.upcomingDeadlines.length > 0 ? (
                summary.upcomingDeadlines.map((deadline, i) => (
                  <div key={i} className="flex items-start gap-4 p-3 rounded-xl bg-secondary/50">
                    <div className="p-2 rounded-lg bg-background shadow-sm mt-0.5">
                      <Clock className="w-4 h-4 text-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-sm truncate">{deadline.title}</p>
                      <p className="text-xs text-muted-foreground mt-1 flex items-center gap-1">
                        {format(new Date(deadline.date), "MMM d, yyyy")}
                        <span className="w-1 h-1 rounded-full bg-muted-foreground/30 mx-1" />
                        <span className="capitalize">{deadline.type}</span>
                      </p>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-6 text-muted-foreground text-sm">
                  No upcoming deadlines. You're all caught up!
                </div>
              )}
            </CardContent>
          </Card>

          {/* Recent Events */}
          <Card>
            <CardHeader className="pb-3 flex flex-row items-center justify-between">
              <CardTitle className="text-lg">Recent Events</CardTitle>
              <Link href="/events" className="text-sm font-medium text-primary hover:underline">
                View all
              </Link>
            </CardHeader>
            <CardContent className="space-y-4">
              {isSummaryLoading ? (
                Array(3).fill(0).map((_, i) => <Skeleton key={i} className="h-16 w-full rounded-xl" />)
              ) : summary?.recentEvents && summary.recentEvents.length > 0 ? (
                summary.recentEvents.slice(0, 3).map((event) => (
                  <Link key={event.id} href={`/events/${event.id}`}>
                    <div className="flex items-center gap-4 p-3 rounded-xl hover:bg-secondary/50 transition-colors cursor-pointer group">
                      <div className="w-12 h-12 rounded-lg bg-primary/10 flex flex-col items-center justify-center shrink-0">
                        <span className="text-xs font-bold text-primary uppercase">{format(new Date(event.date), "MMM")}</span>
                        <span className="text-sm font-bold text-foreground leading-none mt-0.5">{format(new Date(event.date), "dd")}</span>
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-sm truncate group-hover:text-primary transition-colors">{event.title}</p>
                        <p className="text-xs text-muted-foreground mt-1 truncate">{event.location} • {event.time}</p>
                      </div>
                    </div>
                  </Link>
                ))
              ) : (
                <div className="text-center py-6 text-muted-foreground text-sm">
                  No recent events to show.
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}

function StatCard({ icon: Icon, label, value, loading, href }: { icon: any, label: string, value?: number, loading: boolean, href: string }) {
  return (
    <Link href={href}>
      <Card className="hover:border-primary/30 transition-colors cursor-pointer active:scale-95 duration-200">
        <CardContent className="p-4 flex flex-col items-center justify-center text-center">
          <div className="p-2.5 rounded-full bg-primary/10 text-primary mb-3">
            <Icon className="w-5 h-5" />
          </div>
          {loading ? (
            <Skeleton className="h-6 w-8 mb-1" />
          ) : (
            <p className="text-xl font-bold font-heading">{value || 0}</p>
          )}
          <p className="text-xs text-muted-foreground font-medium">{label}</p>
        </CardContent>
      </Card>
    </Link>
  )
}
