import * as React from "react"
import { 
  useListScholarships, 
  getListScholarshipsQueryKey,
  useToggleScholarshipBookmark
} from "@workspace/api-client-react"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Skeleton } from "@/components/ui/skeleton"
import { Search, Clock, Bookmark, Filter, DollarSign, GraduationCap } from "lucide-react"
import { Link } from "wouter"
import { format, formatDistanceToNow } from "date-fns"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useQueryClient } from "@tanstack/react-query"

export default function Scholarships() {
  const [search, setSearch] = React.useState("")
  const [activeTab, setActiveTab] = React.useState("all")
  
  const { data: scholarships, isLoading } = useListScholarships(
    { search: search || undefined, bookmarked: activeTab === "bookmarked" ? true : undefined },
    { query: { queryKey: getListScholarshipsQueryKey({ search: search || undefined, bookmarked: activeTab === "bookmarked" ? true : undefined }) } }
  )

  const toggleBookmark = useToggleScholarshipBookmark()
  const queryClient = useQueryClient()

  const handleBookmark = (e: React.MouseEvent, id: number) => {
    e.preventDefault()
    e.stopPropagation()
    toggleBookmark.mutate({ id }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListScholarshipsQueryKey({ search: search || undefined }) })
        queryClient.invalidateQueries({ queryKey: getListScholarshipsQueryKey({ search: search || undefined, bookmarked: true }) })
      }
    })
  }

  return (
    <div className="flex flex-col min-h-full">
      <header className="sticky top-0 z-30 bg-background/80 backdrop-blur-xl border-b px-4 py-4 md:px-8">
        <h1 className="text-2xl font-bold font-heading mb-4">Scholarships</h1>
        
        <div className="flex gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input 
              placeholder="Search by name, provider..." 
              className="pl-9 bg-secondary/50 border-transparent focus-visible:bg-background"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <Button variant="outline" size="icon" className="shrink-0 bg-secondary/50 border-transparent">
            <Filter className="w-4 h-4" />
          </Button>
        </div>
      </header>

      <main className="flex-1 p-4 md:p-8 max-w-5xl mx-auto w-full">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="w-full grid grid-cols-2 mb-6 p-1 bg-secondary/50 rounded-xl">
            <TabsTrigger value="all" className="rounded-lg">All Opportunities</TabsTrigger>
            <TabsTrigger value="bookmarked" className="rounded-lg">Saved</TabsTrigger>
          </TabsList>
          
          <TabsContent value="all" className="m-0 focus-visible:outline-none">
            <ScholarshipList items={scholarships} isLoading={isLoading} onBookmark={handleBookmark} />
          </TabsContent>
          
          <TabsContent value="bookmarked" className="m-0 focus-visible:outline-none">
            <ScholarshipList items={scholarships} isLoading={isLoading} onBookmark={handleBookmark} />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}

function ScholarshipList({ items, isLoading, onBookmark }: { items: any[], isLoading: boolean, onBookmark: (e: React.MouseEvent, id: number) => void }) {
  if (isLoading) {
    return (
      <div className="space-y-4">
        {Array(4).fill(0).map((_, i) => (
          <Skeleton key={i} className="h-40 w-full rounded-2xl" />
        ))}
      </div>
    )
  }

  if (!items || items.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-center px-4">
        <div className="w-16 h-16 rounded-full bg-secondary flex items-center justify-center mb-4">
          <GraduationCap className="w-8 h-8 text-muted-foreground" />
        </div>
        <h3 className="font-heading text-lg font-semibold mb-2">No scholarships found</h3>
        <p className="text-muted-foreground text-sm max-w-[250px]">
          There are no opportunities matching your criteria right now.
        </p>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {items.map((item) => {
        const deadlineDate = new Date(item.deadline)
        const isUrgent = deadlineDate.getTime() - new Date().getTime() < 7 * 24 * 60 * 60 * 1000 // Less than 7 days

        return (
          <Link key={item.id} href={`/scholarships/${item.id}`}>
            <Card className="group hover:border-primary/30 transition-all hover:shadow-md cursor-pointer overflow-hidden relative">
              {isUrgent && (
                <div className="absolute top-0 left-0 w-1 h-full bg-destructive" />
              )}
              <CardContent className="p-5 flex flex-col md:flex-row gap-5 md:items-center">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-2">
                    <Badge variant="secondary" className="bg-primary/10 text-primary font-medium">{item.category}</Badge>
                    {isUrgent && <Badge variant="destructive" className="font-medium">Ending Soon</Badge>}
                  </div>
                  <h3 className="font-heading font-bold text-lg leading-tight group-hover:text-primary transition-colors mb-1">{item.title}</h3>
                  <p className="text-sm text-muted-foreground">{item.provider}</p>
                  
                  <div className="flex flex-wrap items-center gap-4 mt-4">
                    <div className="flex items-center gap-1.5 text-sm font-semibold text-foreground bg-secondary/50 px-2.5 py-1 rounded-md">
                      <DollarSign className="w-4 h-4 text-primary" />
                      {item.amount}
                    </div>
                    <div className={cn("flex items-center gap-1.5 text-sm", isUrgent ? "text-destructive font-medium" : "text-muted-foreground")}>
                      <Clock className="w-4 h-4" />
                      Due {format(deadlineDate, "MMM d, yyyy")}
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center justify-between md:flex-col md:justify-center gap-4 md:border-l md:pl-5 shrink-0 pt-4 border-t md:pt-0 md:border-t-0">
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="md:absolute md:top-4 md:right-4 text-muted-foreground hover:text-primary hover:bg-primary/10"
                    onClick={(e) => onBookmark(e, item.id)}
                  >
                    <Bookmark className={`w-5 h-5 ${item.isBookmarked ? 'fill-primary text-primary' : ''}`} />
                  </Button>
                  <Button variant="secondary" className="md:mt-8 group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
                    View Details
                  </Button>
                </div>
              </CardContent>
            </Card>
          </Link>
        )
      })}
    </div>
  )
}

function cn(...classes: (string | undefined | null | false)[]) {
  return classes.filter(Boolean).join(" ");
}
