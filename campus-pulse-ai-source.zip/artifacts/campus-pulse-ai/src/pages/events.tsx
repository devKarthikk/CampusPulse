import * as React from "react"
import { 
  useListEvents, 
  getListEventsQueryKey,
  useToggleEventBookmark
} from "@workspace/api-client-react"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Skeleton } from "@/components/ui/skeleton"
import { Search, MapPin, Clock, Calendar as CalendarIcon, Bookmark, Filter } from "lucide-react"
import { Link } from "wouter"
import { format } from "date-fns"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useQueryClient } from "@tanstack/react-query"

export default function Events() {
  const [search, setSearch] = React.useState("")
  const [activeTab, setActiveTab] = React.useState("all")
  
  const { data: events, isLoading } = useListEvents(
    { search: search || undefined, bookmarked: activeTab === "bookmarked" ? true : undefined },
    { query: { queryKey: getListEventsQueryKey({ search: search || undefined, bookmarked: activeTab === "bookmarked" ? true : undefined }) } }
  )

  const toggleBookmark = useToggleEventBookmark()
  const queryClient = useQueryClient()

  const handleBookmark = (e: React.MouseEvent, id: number) => {
    e.preventDefault()
    e.stopPropagation()
    toggleBookmark.mutate({ id }, {
      onSuccess: () => {
        // Invalidate both lists to ensure consistency
        queryClient.invalidateQueries({ queryKey: getListEventsQueryKey({ search: search || undefined }) })
        queryClient.invalidateQueries({ queryKey: getListEventsQueryKey({ search: search || undefined, bookmarked: true }) })
      }
    })
  }

  return (
    <div className="flex flex-col min-h-full">
      <header className="sticky top-0 z-30 bg-background/80 backdrop-blur-xl border-b px-4 py-4 md:px-8">
        <h1 className="text-2xl font-bold font-heading mb-4">Campus Events</h1>
        
        <div className="flex gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input 
              placeholder="Search events..." 
              className="pl-9 bg-secondary/50 border-transparent focus-visible:bg-background"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <Button variant="outline" size="icon" className="shrink-0 bg-secondary/50 border-transparent">
            <Filter className="w-4 h-4" />
          </Button>
        </div>
      </header>

      <main className="flex-1 p-4 md:p-8 max-w-5xl mx-auto w-full">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="w-full grid grid-cols-2 mb-6 p-1 bg-secondary/50 rounded-xl">
            <TabsTrigger value="all" className="rounded-lg">All Events</TabsTrigger>
            <TabsTrigger value="bookmarked" className="rounded-lg">Bookmarked</TabsTrigger>
          </TabsList>
          
          <TabsContent value="all" className="m-0 focus-visible:outline-none">
            <EventGrid events={events} isLoading={isLoading} onBookmark={handleBookmark} />
          </TabsContent>
          
          <TabsContent value="bookmarked" className="m-0 focus-visible:outline-none">
            <EventGrid events={events} isLoading={isLoading} onBookmark={handleBookmark} />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}

function EventGrid({ events, isLoading, onBookmark }: { events: any[], isLoading: boolean, onBookmark: (e: React.MouseEvent, id: number) => void }) {
  if (isLoading) {
    return (
      <div className="grid md:grid-cols-2 gap-4">
        {Array(4).fill(0).map((_, i) => (
          <Skeleton key={i} className="h-48 w-full rounded-2xl" />
        ))}
      </div>
    )
  }

  if (!events || events.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-center px-4">
        <div className="w-16 h-16 rounded-full bg-secondary flex items-center justify-center mb-4">
          <CalendarIcon className="w-8 h-8 text-muted-foreground" />
        </div>
        <h3 className="font-heading text-lg font-semibold mb-2">No events found</h3>
        <p className="text-muted-foreground text-sm max-w-[250px]">
          There are no events matching your criteria right now. Check back later!
        </p>
      </div>
    )
  }

  return (
    <div className="grid md:grid-cols-2 gap-4">
      {events.map((event) => (
        <Link key={event.id} href={`/events/${event.id}`}>
          <Card className="group overflow-hidden hover:border-primary/30 transition-all hover:shadow-md cursor-pointer h-full flex flex-col">
            {event.imageUrl && (
              <div className="w-full h-32 overflow-hidden bg-muted relative">
                <img 
                  src={event.imageUrl} 
                  alt={event.title} 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute top-2 right-2 flex gap-2">
                  <Badge variant="secondary" className="bg-background/80 backdrop-blur-sm shadow-sm">{event.category}</Badge>
                </div>
              </div>
            )}
            <CardContent className="p-5 flex flex-col flex-1">
              {!event.imageUrl && (
                <div className="mb-3">
                  <Badge variant="secondary" className="bg-primary/10 text-primary">{event.category}</Badge>
                </div>
              )}
              <h3 className="font-heading font-bold text-lg line-clamp-1 group-hover:text-primary transition-colors">{event.title}</h3>
              <p className="text-sm text-muted-foreground mt-1 line-clamp-2 flex-1">{event.description}</p>
              
              <div className="mt-4 pt-4 border-t flex items-center justify-between">
                <div className="space-y-1">
                  <div className="flex items-center gap-1.5 text-xs font-medium text-foreground">
                    <CalendarIcon className="w-3.5 h-3.5 text-primary" />
                    {format(new Date(event.date), "MMM d, yyyy")} • {event.time}
                  </div>
                  <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                    <MapPin className="w-3.5 h-3.5" />
                    <span className="truncate max-w-[150px]">{event.location}</span>
                  </div>
                </div>
                
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="shrink-0 -mr-2 text-muted-foreground hover:text-primary hover:bg-primary/10"
                  onClick={(e) => onBookmark(e, event.id)}
                >
                  <Bookmark className={`w-5 h-5 ${event.isBookmarked ? 'fill-primary text-primary' : ''}`} />
                </Button>
              </div>
            </CardContent>
          </Card>
        </Link>
      ))}
    </div>
  )
}
