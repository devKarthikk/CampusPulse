import * as React from "react"
import { 
  useListNotifications, 
  getListNotificationsQueryKey,
  useMarkNotificationRead,
  useMarkAllNotificationsRead,
  NotificationType
} from "@workspace/api-client-react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Skeleton } from "@/components/ui/skeleton"
import { Bell, BellRing, Calendar, GraduationCap, Building2, Megaphone, Info, CheckCircle2 } from "lucide-react"
import { formatDistanceToNow } from "date-fns"
import { useQueryClient } from "@tanstack/react-query"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function Notifications() {
  const [unreadOnly, setUnreadOnly] = React.useState(false)
  const { data: notifications, isLoading } = useListNotifications(
    { unread: unreadOnly ? true : undefined }, 
    { query: { queryKey: getListNotificationsQueryKey({ unread: unreadOnly ? true : undefined }) } }
  )

  const markRead = useMarkNotificationRead()
  const markAllRead = useMarkAllNotificationsRead()
  const queryClient = useQueryClient()

  const handleMarkRead = (id: number) => {
    markRead.mutate({ id }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListNotificationsQueryKey() })
      }
    })
  }

  const handleMarkAllRead = () => {
    markAllRead.mutate(undefined, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListNotificationsQueryKey() })
      }
    })
  }

  const getIcon = (type: NotificationType) => {
    switch(type) {
      case 'event': return <Calendar className="w-5 h-5" />
      case 'scholarship': return <GraduationCap className="w-5 h-5" />
      case 'hostel': return <Building2 className="w-5 h-5" />
      case 'announcement': return <Megaphone className="w-5 h-5" />
      case 'reminder': return <BellRing className="w-5 h-5" />
      default: return <Info className="w-5 h-5" />
    }
  }

  const getColorClass = (type: NotificationType) => {
    switch(type) {
      case 'event': return "bg-blue-500/10 text-blue-600 dark:text-blue-400"
      case 'scholarship': return "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400"
      case 'hostel': return "bg-orange-500/10 text-orange-600 dark:text-orange-400"
      case 'announcement': return "bg-primary/10 text-primary"
      case 'reminder': return "bg-destructive/10 text-destructive"
      default: return "bg-secondary text-muted-foreground"
    }
  }

  return (
    <div className="flex flex-col min-h-full">
      <header className="sticky top-0 z-30 bg-background/80 backdrop-blur-xl border-b px-4 py-4 md:px-8">
        <div className="flex justify-between items-center mb-4">
          <h1 className="text-2xl font-bold font-heading">Notifications</h1>
          <Button 
            variant="ghost" 
            size="sm" 
            className="text-primary hover:text-primary/80 hover:bg-primary/10 -mr-2"
            onClick={handleMarkAllRead}
            disabled={markAllRead.isPending || !notifications?.some(n => !n.isRead)}
          >
            <CheckCircle2 className="w-4 h-4 mr-1" /> Mark all read
          </Button>
        </div>
        
        <Tabs value={unreadOnly ? "unread" : "all"} onValueChange={(v) => setUnreadOnly(v === "unread")} className="w-full">
          <TabsList className="w-full grid grid-cols-2 p-1 bg-secondary/50 rounded-xl">
            <TabsTrigger value="all" className="rounded-lg">All updates</TabsTrigger>
            <TabsTrigger value="unread" className="rounded-lg">Unread</TabsTrigger>
          </TabsList>
        </Tabs>
      </header>

      <main className="flex-1 p-4 md:p-8 max-w-4xl mx-auto w-full">
        {isLoading ? (
          <div className="space-y-3">
            {Array(5).fill(0).map((_, i) => <Skeleton key={i} className="h-24 w-full rounded-2xl" />)}
          </div>
        ) : !notifications || notifications.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-center px-4">
            <div className="w-20 h-20 rounded-full bg-secondary flex items-center justify-center mb-6">
              <Bell className="w-10 h-10 text-muted-foreground" />
            </div>
            <h3 className="font-heading text-lg font-semibold mb-2">You're all caught up!</h3>
            <p className="text-muted-foreground text-sm max-w-[250px]">
              We'll notify you when there are new events, scholarships, or announcements.
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {notifications.map((notification) => (
              <Card 
                key={notification.id} 
                className={`transition-colors border-l-4 overflow-hidden ${
                  !notification.isRead 
                    ? "border-l-primary bg-background shadow-sm hover:border-l-primary" 
                    : "border-l-transparent bg-secondary/30 shadow-none border-t border-r border-b"
                }`}
                onClick={() => !notification.isRead && handleMarkRead(notification.id)}
              >
                <CardContent className="p-4 flex gap-4 cursor-pointer">
                  <div className={`w-12 h-12 rounded-full flex items-center justify-center shrink-0 ${getColorClass(notification.type)}`}>
                    {getIcon(notification.type)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex justify-between items-start mb-1">
                      <h4 className={`font-semibold text-sm pr-4 ${!notification.isRead ? "text-foreground" : "text-muted-foreground"}`}>
                        {notification.title}
                      </h4>
                      <span className="text-xs text-muted-foreground whitespace-nowrap shrink-0">
                        {formatDistanceToNow(new Date(notification.createdAt), { addSuffix: true })}
                      </span>
                    </div>
                    <p className={`text-sm ${!notification.isRead ? "text-foreground/90 font-medium" : "text-muted-foreground"}`}>
                      {notification.message}
                    </p>
                  </div>
                  {!notification.isRead && (
                    <div className="w-2 h-2 rounded-full bg-primary mt-2 shrink-0 self-start" />
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </main>
    </div>
  )
}
