import * as React from "react"
import { 
  useGetScholarship, 
  getGetScholarshipQueryKey,
  useToggleScholarshipBookmark
} from "@workspace/api-client-react"
import { useParams, Link } from "wouter"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Skeleton } from "@/components/ui/skeleton"
import { ArrowLeft, Clock, Bookmark, DollarSign, Building, CheckCircle2, ExternalLink, Tag } from "lucide-react"
import { format } from "date-fns"
import { useQueryClient } from "@tanstack/react-query"

export default function ScholarshipDetail() {
  const { id } = useParams()
  const scholarshipId = parseInt(id || "0")
  
  const { data: scholarship, isLoading } = useGetScholarship(scholarshipId, {
    query: { enabled: !!scholarshipId, queryKey: getGetScholarshipQueryKey(scholarshipId) }
  })

  const toggleBookmark = useToggleScholarshipBookmark()
  const queryClient = useQueryClient()

  const handleBookmark = () => {
    if (!scholarship) return
    toggleBookmark.mutate({ id: scholarshipId }, {
      onSuccess: () => {
        queryClient.setQueryData(getGetScholarshipQueryKey(scholarshipId), (old: any) => 
          old ? { ...old, isBookmarked: !old.isBookmarked } : old
        )
      }
    })
  }

  if (isLoading) {
    return (
      <div className="flex flex-col min-h-full p-4 md:p-8 space-y-6">
        <Skeleton className="h-10 w-24 mb-4" />
        <Skeleton className="h-32 w-full rounded-2xl" />
        <Skeleton className="h-64 w-full rounded-2xl" />
      </div>
    )
  }

  if (!scholarship) {
    return (
      <div className="flex flex-col items-center justify-center min-h-full text-center p-4">
        <h2 className="text-xl font-bold mb-2">Scholarship not found</h2>
        <Button asChild variant="outline">
          <Link href="/scholarships">Back to Scholarships</Link>
        </Button>
      </div>
    )
  }

  return (
    <div className="flex flex-col min-h-[100dvh] pb-24 md:pb-8">
      <header className="sticky top-0 z-30 bg-background/80 backdrop-blur-xl border-b px-4 py-4 flex items-center justify-between">
        <Button asChild variant="ghost" size="icon" className="-ml-2">
          <Link href="/scholarships">
            <ArrowLeft className="w-5 h-5" />
          </Link>
        </Button>
        <div className="font-heading font-semibold truncate px-4 flex-1 text-center">Opportunity Details</div>
        <Button onClick={handleBookmark} variant="ghost" size="icon" className="-mr-2 text-foreground">
          <Bookmark className={`w-5 h-5 ${scholarship.isBookmarked ? 'fill-primary text-primary' : ''}`} />
        </Button>
      </header>

      <main className="flex-1 p-4 md:p-8 max-w-3xl mx-auto w-full space-y-6">
        <div className="space-y-4">
          <Badge className="bg-primary/10 text-primary hover:bg-primary/20 border-transparent">
            {scholarship.category}
          </Badge>
          <h1 className="text-3xl md:text-4xl font-bold font-heading">{scholarship.title}</h1>
          
          <div className="flex flex-wrap gap-3 md:gap-6 mt-4">
            <div className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
              <Building className="w-4 h-4 text-foreground" />
              {scholarship.provider}
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <Card className="bg-primary/5 border-primary/10 shadow-none">
            <CardContent className="p-4 flex flex-col items-center text-center justify-center">
              <DollarSign className="w-6 h-6 text-primary mb-2" />
              <p className="text-sm text-muted-foreground mb-1">Amount</p>
              <p className="text-xl font-bold font-heading text-foreground">{scholarship.amount}</p>
            </CardContent>
          </Card>
          <Card className="bg-destructive/5 border-destructive/10 shadow-none">
            <CardContent className="p-4 flex flex-col items-center text-center justify-center">
              <Clock className="w-6 h-6 text-destructive mb-2" />
              <p className="text-sm text-muted-foreground mb-1">Deadline</p>
              <p className="text-lg font-bold font-heading text-foreground">{format(new Date(scholarship.deadline), "MMM d, yyyy")}</p>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Description</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground leading-relaxed whitespace-pre-wrap">{scholarship.description}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Eligibility Criteria</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-3">
              {scholarship.eligibility.map((criteria, i) => (
                <li key={i} className="flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-primary shrink-0 mt-0.5" />
                  <span className="text-foreground text-sm md:text-base leading-relaxed">{criteria}</span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>

        {scholarship.tags && scholarship.tags.length > 0 && (
          <div className="flex flex-wrap gap-2 pt-4">
            {scholarship.tags.map(tag => (
              <Badge key={tag} variant="outline" className="flex items-center gap-1 font-normal bg-secondary/30">
                <Tag className="w-3 h-3 text-muted-foreground" /> {tag}
              </Badge>
            ))}
          </div>
        )}
      </main>

      <div className="fixed bottom-[72px] md:bottom-0 left-0 right-0 p-4 bg-background/80 backdrop-blur-xl border-t z-40 md:pl-64">
        <div className="max-w-3xl mx-auto flex items-center justify-between gap-4">
          <div className="hidden sm:block">
            <p className="font-semibold text-sm">Ready to apply?</p>
            <p className="text-xs text-muted-foreground">Make sure you meet all criteria</p>
          </div>
          
          {scholarship.applicationUrl ? (
            <Button className="w-full sm:w-auto px-8 gap-2" size="lg" asChild>
              <a href={scholarship.applicationUrl} target="_blank" rel="noopener noreferrer">
                Go to Application <ExternalLink className="w-4 h-4" />
              </a>
            </Button>
          ) : (
            <Button className="w-full sm:w-auto px-8" size="lg" disabled>
              Application Closed
            </Button>
          )}
        </div>
      </div>
    </div>
  )
}
