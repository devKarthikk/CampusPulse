import * as React from "react"
import { 
  useListDocuments, 
  getListDocumentsQueryKey,
  useUploadDocument,
  useDeleteDocument,
  DocumentInputCategory
} from "@workspace/api-client-react"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Skeleton } from "@/components/ui/skeleton"
import { Search, FileText, Download, Trash2, Plus, UploadCloud, Folder, FileCheck, X } from "lucide-react"
import { format } from "date-fns"
import { useQueryClient } from "@tanstack/react-query"
import { useToast } from "@/hooks/use-toast"

export default function Documents() {
  const [search, setSearch] = React.useState("")
  const [category, setCategory] = React.useState<string | undefined>()
  const [isUploading, setIsUploading] = React.useState(false)
  
  const { data: documents, isLoading } = useListDocuments(
    { search: search || undefined, category },
    { query: { queryKey: getListDocumentsQueryKey({ search: search || undefined, category }) } }
  )

  const uploadDoc = useUploadDocument()
  const deleteDoc = useDeleteDocument()
  const queryClient = useQueryClient()
  const { toast } = useToast()

  const categories = ["all", "certificate", "identity", "academic", "other"]

  const handleDelete = (id: number) => {
    deleteDoc.mutate({ id }, {
      onSuccess: () => {
        toast({ title: "Document deleted" })
        queryClient.invalidateQueries({ queryKey: getListDocumentsQueryKey() })
      }
    })
  }

  return (
    <div className="flex flex-col min-h-full bg-secondary/10">
      <header className="sticky top-0 z-30 bg-background/80 backdrop-blur-xl border-b px-4 py-4 md:px-8">
        <div className="flex justify-between items-center mb-4">
          <h1 className="text-2xl font-bold font-heading">Document Vault</h1>
          <Button onClick={() => setIsUploading(!isUploading)} size="sm" className="rounded-full shadow-sm">
            {isUploading ? <X className="w-4 h-4 mr-1" /> : <Plus className="w-4 h-4 mr-1" />}
            {isUploading ? "Cancel" : "Upload"}
          </Button>
        </div>
        
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input 
            placeholder="Search documents..." 
            className="pl-9 bg-background border-border/50 shadow-sm"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
      </header>

      <main className="flex-1 p-4 md:p-8 max-w-5xl mx-auto w-full">
        {isUploading && (
          <UploadForm 
            onClose={() => setIsUploading(false)} 
            onSuccess={() => {
              setIsUploading(false)
              toast({ title: "Document uploaded successfully" })
              queryClient.invalidateQueries({ queryKey: getListDocumentsQueryKey() })
            }}
          />
        )}

        <div className="flex gap-2 overflow-x-auto pb-4 mb-2 scrollbar-hide">
          {categories.map((cat) => (
            <Button
              key={cat}
              variant={category === (cat === "all" ? undefined : cat) ? "default" : "outline"}
              size="sm"
              onClick={() => setCategory(cat === "all" ? undefined : cat)}
              className={`rounded-full px-5 capitalize shrink-0 ${
                category === (cat === "all" ? undefined : cat) 
                  ? "bg-primary text-primary-foreground shadow-sm" 
                  : "bg-background border-border/50 hover:bg-secondary"
              }`}
            >
              {cat}
            </Button>
          ))}
        </div>

        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {Array(4).fill(0).map((_, i) => <Skeleton key={i} className="h-24 w-full rounded-2xl" />)}
          </div>
        ) : !documents || documents.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-center px-4">
            <div className="w-20 h-20 rounded-full bg-secondary flex items-center justify-center mb-6">
              <Folder className="w-10 h-10 text-muted-foreground" />
            </div>
            <h3 className="font-heading text-lg font-semibold mb-2">No documents found</h3>
            <p className="text-muted-foreground text-sm max-w-[250px] mb-6">
              Securely store your certificates, IDs, and academic records here.
            </p>
            <Button onClick={() => setIsUploading(true)} variant="outline" className="rounded-full">
              Upload your first document
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {documents.map((doc) => (
              <Card key={doc.id} className="group hover:border-primary/40 transition-colors shadow-sm">
                <CardContent className="p-4 flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center shrink-0 group-hover:bg-primary group-hover:text-primary-foreground text-primary transition-colors">
                    {doc.category === 'certificate' ? <FileCheck className="w-6 h-6" /> : <FileText className="w-6 h-6" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-sm truncate text-foreground group-hover:text-primary transition-colors">{doc.name}</h3>
                    <div className="flex items-center gap-2 mt-1 text-xs text-muted-foreground">
                      <span className="uppercase tracking-wider">{doc.fileType}</span>
                      <span>•</span>
                      <span>{doc.size}</span>
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">
                      {format(new Date(doc.uploadedAt), "MMM d, yyyy")}
                    </p>
                  </div>
                  <div className="flex flex-col gap-1 shrink-0">
                    <Button variant="ghost" size="icon" className="w-8 h-8 text-muted-foreground hover:text-primary hover:bg-primary/10">
                      <Download className="w-4 h-4" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="w-8 h-8 text-muted-foreground hover:text-destructive hover:bg-destructive/10"
                      onClick={() => handleDelete(doc.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </main>
    </div>
  )
}

function UploadForm({ onClose, onSuccess }: { onClose: () => void, onSuccess: () => void }) {
  const [name, setName] = React.useState("")
  const [category, setCategory] = React.useState<DocumentInputCategory>("other")
  const uploadDoc = useUploadDocument()

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!name.trim()) return
    
    uploadDoc.mutate({
      data: {
        name,
        category,
        fileType: "pdf",
        size: "2.4 MB" // Mock size
      }
    }, {
      onSuccess
    })
  }

  return (
    <Card className="mb-6 border-primary/20 bg-primary/5 shadow-md relative overflow-hidden">
      <div className="absolute top-0 left-0 w-1 h-full bg-primary" />
      <CardContent className="p-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-heading font-semibold flex items-center gap-2">
            <UploadCloud className="w-5 h-5 text-primary" /> Upload Document
          </h3>
          <Button variant="ghost" size="icon" className="w-8 h-8 -mr-2" onClick={onClose}>
            <X className="w-4 h-4" />
          </Button>
        </div>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Document Name</label>
            <Input 
              placeholder="e.g. Fall Semester Transcript" 
              value={name} 
              onChange={(e) => setName(e.target.value)}
              className="bg-background"
              required
            />
          </div>
          
          <div>
            <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Category</label>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
              {(["academic", "certificate", "identity", "other"] as DocumentInputCategory[]).map(cat => (
                <div 
                  key={cat}
                  onClick={() => setCategory(cat)}
                  className={`text-sm text-center py-2 px-3 rounded-lg cursor-pointer capitalize border transition-all ${
                    category === cat 
                      ? "bg-primary text-primary-foreground border-primary font-medium" 
                      : "bg-background border-border/50 text-muted-foreground hover:bg-secondary"
                  }`}
                >
                  {cat}
                </div>
              ))}
            </div>
          </div>
          
          <div className="border-2 border-dashed border-primary/30 bg-background rounded-xl p-6 text-center cursor-pointer hover:bg-primary/5 transition-colors">
            <UploadCloud className="w-8 h-8 text-primary/50 mx-auto mb-2" />
            <p className="text-sm font-medium">Tap to select a file</p>
            <p className="text-xs text-muted-foreground mt-1">PDF, JPG, PNG up to 10MB</p>
          </div>
          
          <div className="flex justify-end gap-2 pt-2">
            <Button type="button" variant="ghost" onClick={onClose}>Cancel</Button>
            <Button type="submit" disabled={uploadDoc.isPending || !name.trim()}>
              {uploadDoc.isPending ? "Uploading..." : "Save Document"}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  )
}
