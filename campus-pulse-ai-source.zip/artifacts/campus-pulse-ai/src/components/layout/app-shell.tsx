import * as React from "react"
import { Link, useLocation } from "wouter"
import { cn } from "@/lib/utils"
import { Home, MessageSquare, Calendar, GraduationCap, FileText, Building2, Bell, User, Menu, HeartPulse } from "lucide-react"

export function AppShell({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();

  const navItems = [
    { icon: Home,          label: "Home",       href: "/" },
    { icon: MessageSquare, label: "AI Chat",    href: "/chat" },
    { icon: Calendar,      label: "Events",     href: "/events" },
    { icon: GraduationCap, label: "Scholarships", href: "/scholarships" },
    { icon: Building2,     label: "Hostel",     href: "/hostel" },
  ];

  const secondaryNavItems = [
    { icon: HeartPulse, label: "Wellness",  href: "/wellness" },
    { icon: FileText,   label: "Vault",     href: "/documents" },
    { icon: Bell,       label: "Updates",   href: "/notifications" },
    { icon: User,       label: "Profile",   href: "/profile" },
  ];

  return (
    <div className="flex min-h-[100dvh] w-full bg-background md:bg-secondary/30">
      {/* Desktop Sidebar */}
      <aside className="hidden md:flex flex-col w-64 border-r bg-card h-screen sticky top-0 px-4 py-6 shadow-sm z-40">
        <Link href="/" className="flex items-center gap-3 px-2 mb-8">
          <div className="w-8 h-8 rounded-xl bg-primary flex items-center justify-center shadow-md">
            <span className="text-primary-foreground font-bold font-heading text-lg">CP</span>
          </div>
          <span className="font-heading font-bold text-xl tracking-tight">Campus Pulse</span>
        </Link>
        
        <nav className="flex-1 flex flex-col gap-1">
          <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2 px-2 mt-4">Main</div>
          {navItems.map((item) => {
            const isActive = location === item.href || (item.href !== "/" && location.startsWith(item.href));
            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-colors",
                  isActive
                    ? "bg-primary text-primary-foreground shadow-sm"
                    : "text-muted-foreground hover:bg-secondary hover:text-foreground"
                )}
              >
                <item.icon className="w-5 h-5" />
                {item.label}
              </Link>
            );
          })}

          <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2 px-2 mt-8">More</div>
          {secondaryNavItems.map((item) => {
            const isActive = location === item.href || (item.href !== "/" && location.startsWith(item.href));
            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-colors",
                  isActive
                    ? "bg-primary text-primary-foreground shadow-sm"
                    : "text-muted-foreground hover:bg-secondary hover:text-foreground"
                )}
              >
                <item.icon className="w-5 h-5" />
                {item.label}
              </Link>
            );
          })}
        </nav>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0 h-[100dvh] md:h-auto overflow-hidden md:overflow-visible">
        <div className="flex-1 overflow-y-auto pb-[72px] md:pb-0 relative scroll-smooth">
          {children}
        </div>
      </main>

      {/* Mobile Bottom Nav */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 h-[72px] bg-card border-t border-border flex items-center justify-around px-2 z-50 safe-area-bottom pb-2">
        {navItems.map((item) => {
          const isActive = location === item.href || (item.href !== "/" && location.startsWith(item.href));
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "flex flex-col items-center justify-center w-16 h-14 gap-1 rounded-xl transition-colors",
                isActive ? "text-primary" : "text-muted-foreground"
              )}
            >
              <div className={cn("p-1.5 rounded-full transition-colors", isActive && "bg-primary/10")}>
                <item.icon className={cn("w-5 h-5", isActive && "fill-primary/20")} />
              </div>
              <span className="text-[10px] font-medium leading-none">{item.label}</span>
            </Link>
          );
        })}
      </nav>
    </div>
  )
}
