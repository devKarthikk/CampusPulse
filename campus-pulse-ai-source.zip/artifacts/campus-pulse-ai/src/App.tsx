import * as React from "react"
import { Route, Switch, Router as WouterRouter } from "wouter"
import { QueryClient, QueryClientProvider } from "@tanstack/react-query"
import { Toaster } from "@/components/ui/toaster"
import { TooltipProvider } from "@/components/ui/tooltip"

import { AppShell } from "@/components/layout/app-shell"
import Dashboard from "@/pages/dashboard"
import AIChat from "@/pages/chat"
import AIChatDetail from "@/pages/chat-detail"
import Events from "@/pages/events"
import EventDetail from "@/pages/event-detail"
import Scholarships from "@/pages/scholarships"
import ScholarshipDetail from "@/pages/scholarship-detail"
import CareerHub from "@/pages/career"
import Documents from "@/pages/documents"
import Hostel from "@/pages/hostel"
import Notifications from "@/pages/notifications"
import Profile from "@/pages/profile"
import AcademicWellness from "@/pages/wellness"
import NotFound from "@/pages/not-found"

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 1000 * 60 * 5, // 5 minutes
      retry: 1,
      refetchOnWindowFocus: false,
    },
  },
})

function Router() {
  return (
    <AppShell>
      <Switch>
        <Route path="/" component={Dashboard} />
        <Route path="/chat" component={AIChat} />
        <Route path="/chat/:id" component={AIChatDetail} />
        <Route path="/events" component={Events} />
        <Route path="/events/:id" component={EventDetail} />
        <Route path="/scholarships" component={Scholarships} />
        <Route path="/scholarships/:id" component={ScholarshipDetail} />
        <Route path="/career" component={CareerHub} />
        <Route path="/documents" component={Documents} />
        <Route path="/hostel" component={Hostel} />
        <Route path="/notifications" component={Notifications} />
        <Route path="/profile" component={Profile} />
        <Route path="/wellness" component={AcademicWellness} />
        <Route component={NotFound} />
      </Switch>
    </AppShell>
  )
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  )
}

export default App
