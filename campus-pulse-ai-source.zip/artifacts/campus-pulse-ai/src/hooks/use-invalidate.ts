import { useQueryClient } from "@tanstack/react-query";
import { getGetProfileQueryKey, getGetDashboardSummaryQueryKey } from "@workspace/api-client-react";

export function useInvalidateAll() {
  const queryClient = useQueryClient();
  return () => {
    queryClient.invalidateQueries();
  }
}
