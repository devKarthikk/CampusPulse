import { Router } from "express";
import { eq } from "drizzle-orm";
import { db, profileTable, eventsTable, notificationsTable, scholarshipsTable, documentsTable } from "@workspace/db";
import {
  GetDashboardSummaryResponse,
  GetDailyQuoteResponse,
} from "@workspace/api-zod";

const router = Router();

const QUOTES = [
  { quote: "The secret of getting ahead is getting started.", author: "Mark Twain" },
  { quote: "It always seems impossible until it's done.", author: "Nelson Mandela" },
  { quote: "Education is the most powerful weapon which you can use to change the world.", author: "Nelson Mandela" },
  { quote: "The future belongs to those who believe in the beauty of their dreams.", author: "Eleanor Roosevelt" },
  { quote: "Success is not final, failure is not fatal: It is the courage to continue that counts.", author: "Winston Churchill" },
  { quote: "Strive not to be a success, but rather to be of value.", author: "Albert Einstein" },
  { quote: "The only way to do great work is to love what you do.", author: "Steve Jobs" },
];

router.get("/dashboard/summary", async (req, res): Promise<void> => {
  const [profiles, events, notifications, scholarships, documents] = await Promise.all([
    db.select().from(profileTable).limit(1),
    db.select().from(eventsTable).orderBy(eventsTable.date).limit(3),
    db.select().from(notificationsTable).orderBy(notificationsTable.createdAt).limit(5),
    db.select().from(scholarshipsTable),
    db.select().from(documentsTable),
  ]);

  const profile = profiles[0];
  const unreadCount = notifications.filter(n => !n.isRead).length;
  const allNotifications = await db.select().from(notificationsTable);
  const totalUnread = allNotifications.filter(n => !n.isRead).length;

  // Upcoming deadlines from scholarships
  const upcomingDeadlines = scholarships
    .filter(s => new Date(s.deadline) > new Date())
    .sort((a, b) => new Date(a.deadline).getTime() - new Date(b.deadline).getTime())
    .slice(0, 3)
    .map(s => ({ title: s.title, date: s.deadline, type: "scholarship" as const }));

  res.json(GetDashboardSummaryResponse.parse({
    studentName: profile?.name ?? "Student",
    unreadNotifications: totalUnread,
    upcomingEvents: events.length,
    activeScholarships: scholarships.length,
    documentsCount: documents.length,
    recentEvents: events.map(e => ({
      id: e.id,
      title: e.title,
      description: e.description,
      date: e.date,
      time: e.time,
      location: e.location,
      category: e.category,
      organizer: e.organizer,
      imageUrl: e.imageUrl ?? null,
      isBookmarked: e.isBookmarked,
      isRegistered: e.isRegistered,
      capacity: e.capacity ?? null,
      registeredCount: e.registeredCount,
      tags: e.tags,
    })),
    recentNotifications: notifications.map(n => ({
      id: n.id,
      title: n.title,
      message: n.message,
      type: n.type as any,
      isRead: n.isRead,
      createdAt: n.createdAt.toISOString(),
    })),
    upcomingDeadlines,
  }));
});

router.get("/dashboard/quote", async (req, res): Promise<void> => {
  const dayOfYear = Math.floor(
    (Date.now() - new Date(new Date().getFullYear(), 0, 0).getTime()) / 86400000
  );
  const quote = QUOTES[dayOfYear % QUOTES.length];
  res.json(GetDailyQuoteResponse.parse(quote));
});

export default router;
