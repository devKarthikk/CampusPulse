import { Router } from "express";
import { db, hostelInfoTable, messMenuTable, leaveRequestsTable, complaintsTable, emergencyContactsTable } from "@workspace/db";
import {
  GetHostelInfoResponse,
  GetMessMenuQueryParams,
  GetMessMenuResponse,
  ListLeaveRequestsResponse,
  SubmitLeaveRequestBody,
  SubmitLeaveRequestResponse,
  ListComplaintsResponse,
  SubmitComplaintBody,
  SubmitComplaintResponse,
  ListEmergencyContactsResponse,
} from "@workspace/api-zod";

const router = Router();

router.get("/hostel/info", async (req, res): Promise<void> => {
  const rows = await db.select().from(hostelInfoTable).limit(1);
  if (rows.length === 0) { res.status(404).json({ error: "Hostel info not found" }); return; }
  const h = rows[0];
  res.json(GetHostelInfoResponse.parse({
    hostelName: h.hostelName, roomNumber: h.roomNumber, warden: h.warden,
    wardenPhone: h.wardenPhone, address: h.address, facilities: h.facilities,
    checkInTime: h.checkInTime, checkOutTime: h.checkOutTime, rules: h.rules,
  }));
});

router.get("/hostel/menu", async (req, res): Promise<void> => {
  const parsed = GetMessMenuQueryParams.safeParse(req.query);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const { day } = parsed.data;

  let menu = await db.select().from(messMenuTable);
  if (day) {
    menu = menu.filter(m => m.day.toLowerCase() === day.toLowerCase());
  }

  res.json(GetMessMenuResponse.parse(menu.map(m => ({
    day: m.day, breakfast: m.breakfast, lunch: m.lunch, dinner: m.dinner, snacks: m.snacks,
  }))));
});

router.get("/hostel/leaves", async (req, res): Promise<void> => {
  const rows = await db.select().from(leaveRequestsTable);
  res.json(ListLeaveRequestsResponse.parse(rows.map(r => ({
    id: r.id, fromDate: r.fromDate, toDate: r.toDate, reason: r.reason,
    status: r.status as any, submittedAt: r.submittedAt.toISOString(),
    remarks: r.remarks ?? null,
  }))));
});

router.post("/hostel/leaves", async (req, res): Promise<void> => {
  const parsed = SubmitLeaveRequestBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }

  const inserted = await db.insert(leaveRequestsTable).values({
    fromDate: parsed.data.fromDate,
    toDate: parsed.data.toDate,
    reason: parsed.data.reason,
    status: "pending",
  }).returning();

  const r = inserted[0];
  res.status(201).json(SubmitLeaveRequestResponse.parse({
    id: r.id, fromDate: r.fromDate, toDate: r.toDate, reason: r.reason,
    status: r.status as any, submittedAt: r.submittedAt.toISOString(), remarks: r.remarks ?? null,
  }));
});

router.get("/hostel/complaints", async (req, res): Promise<void> => {
  const rows = await db.select().from(complaintsTable);
  res.json(ListComplaintsResponse.parse(rows.map(c => ({
    id: c.id, title: c.title, description: c.description, category: c.category,
    status: c.status as any, submittedAt: c.submittedAt.toISOString(),
    resolvedAt: c.resolvedAt?.toISOString() ?? null,
  }))));
});

router.post("/hostel/complaints", async (req, res): Promise<void> => {
  const parsed = SubmitComplaintBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }

  const inserted = await db.insert(complaintsTable).values({
    title: parsed.data.title,
    description: parsed.data.description,
    category: parsed.data.category,
    status: "open",
  }).returning();

  const c = inserted[0];
  res.status(201).json(SubmitComplaintResponse.parse({
    id: c.id, title: c.title, description: c.description, category: c.category,
    status: c.status as any, submittedAt: c.submittedAt.toISOString(), resolvedAt: null,
  }));
});

router.get("/hostel/contacts", async (req, res): Promise<void> => {
  const rows = await db.select().from(emergencyContactsTable);
  res.json(ListEmergencyContactsResponse.parse(rows.map(c => ({
    id: c.id, name: c.name, role: c.role, phone: c.phone, available: c.available,
  }))));
});

export default router;
