import { Router } from "express";
import { db, careerResourcesTable, careerRoadmapsTable, skillRecommendationsTable } from "@workspace/db";
import {
  ListCareerResourcesQueryParams,
  ListCareerResourcesResponse,
  ListCareerRoadmapsResponse,
  ListSkillRecommendationsResponse,
} from "@workspace/api-zod";

const router = Router();

router.get("/career/resources", async (req, res): Promise<void> => {
  const parsed = ListCareerResourcesQueryParams.safeParse(req.query);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const { category } = parsed.data;

  let resources = await db.select().from(careerResourcesTable);
  if (category) {
    resources = resources.filter(r => r.category === category);
  }

  res.json(ListCareerResourcesResponse.parse(resources.map(r => ({
    id: r.id, title: r.title, description: r.description, category: r.category as any,
    content: r.content, tags: r.tags, readTime: r.readTime,
  }))));
});

router.get("/career/roadmaps", async (req, res): Promise<void> => {
  const roadmaps = await db.select().from(careerRoadmapsTable);
  res.json(ListCareerRoadmapsResponse.parse(roadmaps.map(r => ({
    id: r.id, title: r.title, domain: r.domain, description: r.description,
    steps: r.steps as any, duration: r.duration, difficulty: r.difficulty as any,
  }))));
});

router.get("/career/skills", async (req, res): Promise<void> => {
  const skills = await db.select().from(skillRecommendationsTable);
  res.json(ListSkillRecommendationsResponse.parse(skills.map(s => ({
    id: s.id, skill: s.skill, category: s.category, reason: s.reason,
    priority: s.priority as any, resources: s.resources,
  }))));
});

export default router;
