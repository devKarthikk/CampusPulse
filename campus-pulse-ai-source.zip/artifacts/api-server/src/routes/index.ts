import { Router, type IRouter } from "express";
import healthRouter from "./health";
import profileRouter from "./profile";
import dashboardRouter from "./dashboard";
import eventsRouter from "./events";
import scholarshipsRouter from "./scholarships";
import careerRouter from "./career";
import documentsRouter from "./documents";
import hostelRouter from "./hostel";
import notificationsRouter from "./notifications";
import chatRouter from "./chat";
import wellnessRouter from "./wellness";

const router: IRouter = Router();

router.use(healthRouter);
router.use(profileRouter);
router.use(dashboardRouter);
router.use(eventsRouter);
router.use(scholarshipsRouter);
router.use(careerRouter);
router.use(documentsRouter);
router.use(hostelRouter);
router.use(notificationsRouter);
router.use(chatRouter);
router.use(wellnessRouter);

export default router;
