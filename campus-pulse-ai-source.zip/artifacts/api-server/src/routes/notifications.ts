import { Router } from "express";
import { eq } from "drizzle-orm";
import { db, notificationsTable } from "@workspace/db";
import {
  ListNotificationsQueryParams,
  ListNotificationsResponse,
  MarkNotificationReadParams,
  MarkNotificationReadResponse,
  MarkAllNotificationsReadResponse,
} from "@workspace/api-zod";

const router = Router();

router.get("/notifications", async (req, res): Promise<void> => {
  const parsed = ListNotificationsQueryParams.safeParse(req.query);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const { unread } = parsed.data;

  let rows = await db.select().from(notificationsTable);
  rows = rows.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());

  if (unread === true) {
    rows = rows.filter(n => !n.isRead);
  }

  res.json(ListNotificationsResponse.parse(rows.map(n => ({
    id: n.id, title: n.title, message: n.message, type: n.type as any,
    isRead: n.isRead, createdAt: n.createdAt.toISOString(),
  }))));
});

router.post("/notifications/:id/read", async (req, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(rawId, 10);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }

  const updated = await db
    .update(notificationsTable)
    .set({ isRead: true })
    .where(eq(notificationsTable.id, id))
    .returning();

  if (updated.length === 0) { res.status(404).json({ error: "Notification not found" }); return; }
  const n = updated[0];
  res.json(MarkNotificationReadResponse.parse({
    id: n.id, title: n.title, message: n.message, type: n.type as any,
    isRead: n.isRead, createdAt: n.createdAt.toISOString(),
  }));
});

router.post("/notifications/read-all", async (req, res): Promise<void> => {
  await db.update(notificationsTable).set({ isRead: true });
  res.json(MarkAllNotificationsReadResponse.parse({ success: true, message: "All notifications marked as read" }));
});

export default router;
