import { Router } from "express";
import { eq, asc, desc } from "drizzle-orm";
import { db, chatSessionsTable, messagesTable } from "@workspace/db";
import {
  ListChatSessionsResponse,
  CreateChatSessionBody,
  CreateChatSessionResponse,
  GetChatSessionResponse,
  DeleteChatSessionResponse,
  SendMessageBody,
  SendMessageResponse,
} from "@workspace/api-zod";
import { generateAIResponse, type ChatMessage } from "../lib/ai-service.js";

const router = Router();

// ─── List sessions ────────────────────────────────────────────────────────────

router.get("/chat/sessions", async (_req, res): Promise<void> => {
  const sessions = await db
    .select()
    .from(chatSessionsTable)
    .orderBy(desc(chatSessionsTable.updatedAt));

  const sessionDetails = await Promise.all(
    sessions.map(async (session) => {
      const msgs = await db
        .select()
        .from(messagesTable)
        .where(eq(messagesTable.sessionId, session.id))
        .orderBy(asc(messagesTable.createdAt));
      const lastMsg = msgs.length > 0 ? msgs[msgs.length - 1].content : null;
      return {
        id: session.id,
        title: session.title,
        createdAt: session.createdAt.toISOString(),
        updatedAt: session.updatedAt.toISOString(),
        messageCount: msgs.length,
        lastMessage: lastMsg,
      };
    })
  );

  res.json(ListChatSessionsResponse.parse(sessionDetails));
});

// ─── Create session ───────────────────────────────────────────────────────────

router.post("/chat/sessions", async (req, res): Promise<void> => {
  const parsed = CreateChatSessionBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const inserted = await db
    .insert(chatSessionsTable)
    .values({ title: parsed.data.title })
    .returning();
  const s = inserted[0];

  res.status(201).json(
    CreateChatSessionResponse.parse({
      id: s.id,
      title: s.title,
      createdAt: s.createdAt.toISOString(),
      updatedAt: s.updatedAt.toISOString(),
      messageCount: 0,
      lastMessage: null,
    })
  );
});

// ─── Get session with messages ────────────────────────────────────────────────

router.get("/chat/sessions/:id", async (req, res): Promise<void> => {
  const id = parseInt(req.params.id, 10);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }

  const sessions = await db
    .select()
    .from(chatSessionsTable)
    .where(eq(chatSessionsTable.id, id));
  if (sessions.length === 0) { res.status(404).json({ error: "Session not found" }); return; }

  const msgs = await db
    .select()
    .from(messagesTable)
    .where(eq(messagesTable.sessionId, id))
    .orderBy(asc(messagesTable.createdAt));

  const s = sessions[0];
  res.json(
    GetChatSessionResponse.parse({
      id: s.id,
      title: s.title,
      createdAt: s.createdAt.toISOString(),
      updatedAt: s.updatedAt.toISOString(),
      messages: msgs.map((m) => ({
        id: m.id,
        sessionId: m.sessionId,
        role: m.role as "user" | "assistant",
        content: m.content,
        createdAt: m.createdAt.toISOString(),
      })),
    })
  );
});

// ─── Delete session ───────────────────────────────────────────────────────────

router.delete("/chat/sessions/:id", async (req, res): Promise<void> => {
  const id = parseInt(req.params.id, 10);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }

  await db.delete(chatSessionsTable).where(eq(chatSessionsTable.id, id));
  res.json(DeleteChatSessionResponse.parse({ success: true, message: "Chat session deleted" }));
});

// ─── Send message (with full conversation history passed to Gemma 4) ──────────

router.post("/chat/sessions/:id/messages", async (req, res): Promise<void> => {
  const id = parseInt(req.params.id, 10);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }

  const parsed = SendMessageBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }

  const sessions = await db
    .select()
    .from(chatSessionsTable)
    .where(eq(chatSessionsTable.id, id));
  if (sessions.length === 0) { res.status(404).json({ error: "Session not found" }); return; }

  // 1. Persist the user message first
  await db.insert(messagesTable).values({
    sessionId: id,
    role: "user",
    content: parsed.data.content,
  });

  // 2. Fetch the full conversation history (ordered chronologically)
  const allMessages = await db
    .select()
    .from(messagesTable)
    .where(eq(messagesTable.sessionId, id))
    .orderBy(asc(messagesTable.createdAt));

  // 3. Build typed history for the AI service
  const history: ChatMessage[] = allMessages.map((m) => ({
    role: m.role as "user" | "assistant",
    content: m.content,
  }));

  // 4. Call Gemma 4 with full history
  const aiContent = await generateAIResponse(history);

  // 5. Persist the assistant response
  const inserted = await db
    .insert(messagesTable)
    .values({ sessionId: id, role: "assistant", content: aiContent })
    .returning();

  const m = inserted[0];
  res.json(
    SendMessageResponse.parse({
      id: m.id,
      sessionId: m.sessionId,
      role: m.role as "user" | "assistant",
      content: m.content,
      createdAt: m.createdAt.toISOString(),
    })
  );
});

export default router;
