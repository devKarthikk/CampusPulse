import { Router } from "express";
import { getWellnessData, buildWellnessPrompt } from "../lib/wellness-service.js";
import { generateStructuredResponse } from "../lib/ai-service.js";

const router = Router();

/** GET /api/wellness/data — returns raw mock academic wellness data */
router.get("/wellness/data", async (_req, res): Promise<void> => {
  try {
    const data = getWellnessData();
    res.json(data);
  } catch (err) {
    console.error("[wellness] /data error:", err);
    res.status(500).json({ error: "Failed to fetch wellness data." });
  }
});

/** POST /api/wellness/analysis — generates AI-powered wellness report via the AI backend */
router.post("/wellness/analysis", async (_req, res): Promise<void> => {
  try {
    const data = getWellnessData();
    const prompt = buildWellnessPrompt(data);
    const analysis = await generateStructuredResponse(prompt);
    res.json({ analysis, generatedAt: new Date().toISOString() });
  } catch (err) {
    console.error("[wellness] /analysis error:", err);
    res.status(500).json({ error: "Failed to generate wellness analysis." });
  }
});

export default router;
