import { Router } from "express";
import { eq } from "drizzle-orm";
import { db, scholarshipsTable } from "@workspace/db";
import {
  ListScholarshipsQueryParams,
  ListScholarshipsResponse,
  GetScholarshipParams,
  GetScholarshipResponse,
  ToggleScholarshipBookmarkParams,
  ToggleScholarshipBookmarkResponse,
} from "@workspace/api-zod";

const router = Router();

router.get("/scholarships", async (req, res): Promise<void> => {
  const parsed = ListScholarshipsQueryParams.safeParse(req.query);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const { search, bookmarked } = parsed.data;

  let scholarships = await db.select().from(scholarshipsTable);
  if (search) {
    const s = search.toLowerCase();
    scholarships = scholarships.filter(
      sc => sc.title.toLowerCase().includes(s) || sc.provider.toLowerCase().includes(s)
    );
  }
  if (bookmarked === true) {
    scholarships = scholarships.filter(sc => sc.isBookmarked);
  }

  res.json(ListScholarshipsResponse.parse(scholarships.map(sc => ({
    id: sc.id, title: sc.title, provider: sc.provider, amount: sc.amount,
    deadline: sc.deadline, description: sc.description, eligibility: sc.eligibility,
    applicationUrl: sc.applicationUrl ?? null, isBookmarked: sc.isBookmarked,
    category: sc.category, tags: sc.tags,
  }))));
});

router.get("/scholarships/:id", async (req, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(rawId, 10);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }

  const rows = await db.select().from(scholarshipsTable).where(eq(scholarshipsTable.id, id));
  if (rows.length === 0) { res.status(404).json({ error: "Scholarship not found" }); return; }
  const sc = rows[0];
  res.json(GetScholarshipResponse.parse({
    id: sc.id, title: sc.title, provider: sc.provider, amount: sc.amount,
    deadline: sc.deadline, description: sc.description, eligibility: sc.eligibility,
    applicationUrl: sc.applicationUrl ?? null, isBookmarked: sc.isBookmarked,
    category: sc.category, tags: sc.tags,
  }));
});

router.post("/scholarships/:id/bookmark", async (req, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(rawId, 10);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }

  const rows = await db.select().from(scholarshipsTable).where(eq(scholarshipsTable.id, id));
  if (rows.length === 0) { res.status(404).json({ error: "Scholarship not found" }); return; }

  const updated = await db
    .update(scholarshipsTable)
    .set({ isBookmarked: !rows[0].isBookmarked })
    .where(eq(scholarshipsTable.id, id))
    .returning();

  res.json(ToggleScholarshipBookmarkResponse.parse({ bookmarked: updated[0].isBookmarked }));
});

export default router;
