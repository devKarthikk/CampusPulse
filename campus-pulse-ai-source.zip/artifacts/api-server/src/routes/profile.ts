import { Router } from "express";
import { eq } from "drizzle-orm";
import { db, profileTable } from "@workspace/db";
import {
  GetProfileResponse,
  UpdateProfileBody,
  UpdateProfileResponse,
} from "@workspace/api-zod";

const router = Router();

router.get("/profile", async (req, res): Promise<void> => {
  const profiles = await db.select().from(profileTable).limit(1);
  if (profiles.length === 0) {
    res.status(404).json({ error: "Profile not found" });
    return;
  }
  const p = profiles[0];
  res.json(GetProfileResponse.parse({
    id: p.id,
    name: p.name,
    email: p.email,
    studentId: p.studentId,
    department: p.department,
    year: p.year,
    cgpa: p.cgpa,
    phone: p.phone ?? null,
    avatar: p.avatar ?? null,
    skills: p.skills,
    interests: p.interests,
    bio: p.bio ?? null,
    linkedinUrl: p.linkedinUrl ?? null,
    githubUrl: p.githubUrl ?? null,
  }));
});

router.put("/profile", async (req, res): Promise<void> => {
  const parsed = UpdateProfileBody.safeParse(req.body);
  if (!parsed.success) {
    req.log.warn({ errors: parsed.error.message }, "Invalid profile update body");
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const profiles = await db.select().from(profileTable).limit(1);
  if (profiles.length === 0) {
    res.status(404).json({ error: "Profile not found" });
    return;
  }
  const data = parsed.data;
  const updated = await db
    .update(profileTable)
    .set({
      ...(data.name !== undefined && { name: data.name }),
      ...(data.phone !== undefined && { phone: data.phone }),
      ...(data.bio !== undefined && { bio: data.bio }),
      ...(data.skills !== undefined && { skills: data.skills }),
      ...(data.interests !== undefined && { interests: data.interests }),
      ...(data.linkedinUrl !== undefined && { linkedinUrl: data.linkedinUrl }),
      ...(data.githubUrl !== undefined && { githubUrl: data.githubUrl }),
    })
    .where(eq(profileTable.id, profiles[0].id))
    .returning();
  const p = updated[0];
  res.json(UpdateProfileResponse.parse({
    id: p.id,
    name: p.name,
    email: p.email,
    studentId: p.studentId,
    department: p.department,
    year: p.year,
    cgpa: p.cgpa,
    phone: p.phone ?? null,
    avatar: p.avatar ?? null,
    skills: p.skills,
    interests: p.interests,
    bio: p.bio ?? null,
    linkedinUrl: p.linkedinUrl ?? null,
    githubUrl: p.githubUrl ?? null,
  }));
});

export default router;
