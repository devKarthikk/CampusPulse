import { Router } from "express";
import { eq, ilike, and } from "drizzle-orm";
import { db, eventsTable } from "@workspace/db";
import {
  ListEventsQueryParams,
  ListEventsResponse,
  GetEventParams,
  GetEventResponse,
  ToggleEventBookmarkParams,
  ToggleEventBookmarkResponse,
  RegisterForEventParams,
  RegisterForEventResponse,
} from "@workspace/api-zod";

const router = Router();

router.get("/events", async (req, res): Promise<void> => {
  const parsed = ListEventsQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const { search, category, bookmarked } = parsed.data;

  let events = await db.select().from(eventsTable);

  if (search) {
    const s = search.toLowerCase();
    events = events.filter(
      e => e.title.toLowerCase().includes(s) || e.description.toLowerCase().includes(s)
    );
  }
  if (category) {
    events = events.filter(e => e.category === category);
  }
  if (bookmarked === true) {
    events = events.filter(e => e.isBookmarked);
  }

  res.json(ListEventsResponse.parse(events.map(e => ({
    id: e.id,
    title: e.title,
    description: e.description,
    date: e.date,
    time: e.time,
    location: e.location,
    category: e.category,
    organizer: e.organizer,
    imageUrl: e.imageUrl ?? null,
    isBookmarked: e.isBookmarked,
    isRegistered: e.isRegistered,
    capacity: e.capacity ?? null,
    registeredCount: e.registeredCount,
    tags: e.tags,
  }))));
});

router.get("/events/:id", async (req, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(rawId, 10);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }

  const events = await db.select().from(eventsTable).where(eq(eventsTable.id, id));
  if (events.length === 0) { res.status(404).json({ error: "Event not found" }); return; }

  const e = events[0];
  res.json(GetEventResponse.parse({
    id: e.id, title: e.title, description: e.description, date: e.date, time: e.time,
    location: e.location, category: e.category, organizer: e.organizer,
    imageUrl: e.imageUrl ?? null, isBookmarked: e.isBookmarked, isRegistered: e.isRegistered,
    capacity: e.capacity ?? null, registeredCount: e.registeredCount, tags: e.tags,
  }));
});

router.post("/events/:id/bookmark", async (req, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(rawId, 10);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }

  const events = await db.select().from(eventsTable).where(eq(eventsTable.id, id));
  if (events.length === 0) { res.status(404).json({ error: "Event not found" }); return; }

  const updated = await db
    .update(eventsTable)
    .set({ isBookmarked: !events[0].isBookmarked })
    .where(eq(eventsTable.id, id))
    .returning();

  res.json(ToggleEventBookmarkResponse.parse({ bookmarked: updated[0].isBookmarked }));
});

router.post("/events/:id/register", async (req, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(rawId, 10);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }

  const events = await db.select().from(eventsTable).where(eq(eventsTable.id, id));
  if (events.length === 0) { res.status(404).json({ error: "Event not found" }); return; }

  const event = events[0];
  if (event.isRegistered) {
    res.json(RegisterForEventResponse.parse({ registered: true, message: "Already registered" }));
    return;
  }

  await db
    .update(eventsTable)
    .set({ isRegistered: true, registeredCount: event.registeredCount + 1 })
    .where(eq(eventsTable.id, id));

  res.json(RegisterForEventResponse.parse({ registered: true, message: "Successfully registered for event" }));
});

export default router;
