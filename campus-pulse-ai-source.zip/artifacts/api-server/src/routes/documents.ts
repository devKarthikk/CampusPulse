import { Router } from "express";
import { eq } from "drizzle-orm";
import { db, documentsTable } from "@workspace/db";
import {
  ListDocumentsQueryParams,
  ListDocumentsResponse,
  UploadDocumentBody,
  UploadDocumentResponse,
  DeleteDocumentParams,
  DeleteDocumentResponse,
} from "@workspace/api-zod";

const router = Router();

router.get("/documents", async (req, res): Promise<void> => {
  const parsed = ListDocumentsQueryParams.safeParse(req.query);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const { search, category } = parsed.data;

  let docs = await db.select().from(documentsTable);
  if (search) {
    const s = search.toLowerCase();
    docs = docs.filter(d => d.name.toLowerCase().includes(s));
  }
  if (category) {
    docs = docs.filter(d => d.category === category);
  }

  res.json(ListDocumentsResponse.parse(docs.map(d => ({
    id: d.id, name: d.name, category: d.category as any, size: d.size,
    uploadedAt: d.uploadedAt.toISOString(), fileType: d.fileType, url: d.url ?? null,
  }))));
});

router.post("/documents", async (req, res): Promise<void> => {
  const parsed = UploadDocumentBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }

  const inserted = await db.insert(documentsTable).values({
    name: parsed.data.name,
    category: parsed.data.category,
    size: parsed.data.size,
    fileType: parsed.data.fileType,
    url: null,
  }).returning();

  const d = inserted[0];
  res.status(201).json(UploadDocumentResponse.parse({
    id: d.id, name: d.name, category: d.category as any, size: d.size,
    uploadedAt: d.uploadedAt.toISOString(), fileType: d.fileType, url: d.url ?? null,
  }));
});

router.delete("/documents/:id", async (req, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(rawId, 10);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }

  await db.delete(documentsTable).where(eq(documentsTable.id, id));
  res.json(DeleteDocumentResponse.parse({ success: true, message: "Document deleted" }));
});

export default router;
