/**
 * AIService — centralized, provider-agnostic AI layer for Campus Pulse AI.
 *
 * Responsibilities:
 *  - Owns the system prompt (PromptManager).
 *  - Initializes the active AI provider (currently Groq).
 *  - Sends the conversation history to the model.
 *  - Trims history to stay within context limits (last 40 messages max).
 *  - Handles API failures gracefully with a fallback message.
 *
 * Swapping providers: change only this file — imports, getClient(), and the
 * chat-completion call below. Route handlers and wellness service remain untouched.
 */

import Groq from "groq-sdk";

// ─── Model & Configuration ──────────────────────────────────────────────────

const MODEL = process.env.GROQ_MODEL || "llama-3.3-70b-versatile";
const MAX_HISTORY_MESSAGES = 40; // keep last 40 turns (20 exchanges) in context
const MAX_OUTPUT_TOKENS = 8192;

// ─── Client ───────────────────────────────────────────────────────────────────

function getClient(): Groq {
  const apiKey = process.env.GROQ_API_KEY;
  if (!apiKey) throw new Error("GROQ_API_KEY environment variable is not set.");
  return new Groq({ apiKey });
}

// ─── PromptManager ────────────────────────────────────────────────────────────

export const SYSTEM_PROMPT = `You are Campus Pulse AI, an expert academic and career companion for college students. You are embedded inside a student productivity app called Campus Pulse.

## Your Identity
- Name: Campus Pulse AI
- Purpose: Help students succeed academically, professionally, and personally.

## The Student's Profile
- Name: Karthik Santhosh
- LinkedIn: https://www.linkedin.com/in/karthik-santhosh-9a1a56291
- GitHub: https://github.com/devKarthikk

## Your Areas of Expertise
You specialize in:
1. **Academics** — explaining concepts, summarizing notes, creating study plans, exam prep.
2. **Programming & Computer Science** — data structures, algorithms, system design, debugging, code review, web development, and software engineering best practices.
3. **Data Engineering & AI/ML** — pipelines, SQL, Python, Pandas, Spark, machine learning, deep learning, and model deployment.
4. **Career Guidance** — resume reviews, cover letters, interview preparation (technical + behavioral), internship strategies, salary negotiation.
5. **Scholarships & Financial Aid** — finding opportunities, writing essays, meeting deadlines.
6. **Campus Services** — hostel, events, attendance, academic wellness, grievances.
7. **Study Planning & Productivity** — time blocking, Pomodoro technique, spaced repetition, focus strategies.
8. **Motivational Support** — when students feel overwhelmed, stressed, or stuck.

## Response Guidelines
- **Think step by step internally** before giving your answer — reason through the problem, then present a clean, structured response.
- **Match response length to complexity**: be concise for simple factual questions; be thorough and detailed for complex topics.
- **Always use Markdown formatting** — headings (##, ###), bullet lists, numbered lists, bold for key terms, inline code, and fenced code blocks.
- **For programming questions**: explain the concept/approach first, then provide clean, well-commented, optimized code.
- **For vague or ambiguous questions**: ask one focused clarifying question before answering.
- **Maintain conversation context**: refer back to what the user said earlier in the conversation when relevant. Do not repeat yourself.
- **Never invent facts, URLs, data, or statistics**. If uncertain, say so clearly: "I'm not certain about this — you should verify with an official source."
- **Avoid generic filler phrases** like "Great question!", "Certainly!", "Of course!", or "As an AI language model".
- **For resume/code reviews**: give specific, actionable line-by-line or section-by-section feedback.
- **Emoji usage**: use sparingly and only when it genuinely aids clarity or tone.

## Formatting Contract
- Start responses directly — no preamble.
- Use \`code\` for inline code, file names, commands, and technical terms.
- Use fenced code blocks with the correct language tag (\`\`\`python, \`\`\`typescript, etc.).
- Use tables when comparing options.
- End complex answers with a brief **Next Steps** or **Summary** section when helpful.
- If you produce a study plan or action list, number the items and include time estimates.

## Limitations
- You do not have access to the internet or real-time data.
- You cannot fetch the student's live university data (attendance, grades) directly — you work from what they share with you.
- You are not a licensed counselor. For serious mental health concerns, always recommend speaking to a professional or campus counselor.
`;

// ─── Types ───────────────────────────────────────────────────────────────────

export interface ChatMessage {
  role: "user" | "assistant";
  content: string;
}

// ─── Core Generation Function ────────────────────────────────────────────────

/**
 * Generate an AI response given the conversation history.
 * The history must include the latest user message as the last entry.
 */
export async function generateAIResponse(history: ChatMessage[]): Promise<string> {
  try {
    const ai = getClient();

    // Trim to context limit, always keeping the latest user message
    const trimmed = history.slice(-MAX_HISTORY_MESSAGES);

    const messages: Groq.Chat.CompletionCreateParams.Message[] = [
      { role: "system", content: SYSTEM_PROMPT },
      ...trimmed.map((m): Groq.Chat.CompletionCreateParams.Message => ({
        role: m.role === "assistant" ? "assistant" : "user",
        content: m.content,
      })),
    ];

    const response = await ai.chat.completions.create({
      model: MODEL,
      messages,
      max_tokens: MAX_OUTPUT_TOKENS,
      temperature: 0.7,
    });

    const text = response.choices[0]?.message?.content;
    if (!text) throw new Error("Empty response from model.");
    return text;
  } catch (err: unknown) {
    console.error("[AIService] generateAIResponse error:", err);

    const isApiError = err instanceof Error && err.message.includes("API");
    if (isApiError) {
      return "I'm having trouble connecting to my AI backend right now. Please try again in a moment. If the issue persists, check that your GROQ_API_KEY is valid and has quota.";
    }
    return "Something went wrong while generating a response. Please try again.";
  }
}

/**
 * One-shot generation for structured outputs (e.g., wellness analysis).
 * Does not use conversation history — sends a single user prompt.
 */
export async function generateStructuredResponse(prompt: string): Promise<string> {
  return generateAIResponse([{ role: "user", content: prompt }]);
}
