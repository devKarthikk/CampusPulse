/**
 * WellnessService — mock academic wellness data layer.
 *
 * Designed to be replaced by a real university ERP/API integration later.
 * All data lives here and is passed to the AI backend for analysis.
 */

export interface Exam {
  subject: string;
  date: string;         // ISO date string
  type: "Internal" | "External" | "Quiz" | "Lab";
  syllabus?: string;
}

export interface Assignment {
  subject: string;
  title: string;
  deadline: string;     // ISO date string
  status: "pending" | "submitted" | "overdue";
  weightage?: string;
}

export interface SubjectAttendance {
  subject: string;
  attended: number;
  total: number;
  percentage: number;
}

export interface WellnessData {
  studentName: string;
  department: string;
  year: number;
  semester: number;
  cgpa: number;
  overallAttendancePercentage: number;
  subjectAttendance: SubjectAttendance[];
  upcomingExams: Exam[];
  assignments: Assignment[];
  semesterProgress: number;        // 0–100 percent of semester elapsed
  creditsCompleted: number;
  creditsRequired: number;
  backlogs: number;
  lastUpdated: string;
}

const today = new Date();
const daysFromNow = (n: number) => {
  const d = new Date(today);
  d.setDate(d.getDate() + n);
  return d.toISOString().split("T")[0];
};

export function getWellnessData(): WellnessData {
  return {
    studentName: "Karthik Santhosh",
    department: "Computer Science & Engineering",
    year: 3,
    semester: 5,
    cgpa: 8.2,
    overallAttendancePercentage: 72,
    subjectAttendance: [
      { subject: "Database Management Systems",       attended: 28, total: 38, percentage: 73.7 },
      { subject: "Operating Systems",                 attended: 22, total: 36, percentage: 61.1 },
      { subject: "Computer Networks",                 attended: 31, total: 40, percentage: 77.5 },
      { subject: "Software Engineering",              attended: 33, total: 38, percentage: 86.8 },
      { subject: "Design & Analysis of Algorithms",  attended: 26, total: 36, percentage: 72.2 },
      { subject: "Web Technologies Lab",              attended: 18, total: 20, percentage: 90.0 },
    ],
    upcomingExams: [
      { subject: "Database Management Systems",      date: daysFromNow(5),  type: "Internal", syllabus: "Units 1–3: ER Model, Normalization, SQL" },
      { subject: "Operating Systems",                date: daysFromNow(7),  type: "Internal", syllabus: "Units 1–2: Process Management, Scheduling" },
      { subject: "Computer Networks",                date: daysFromNow(12), type: "Internal", syllabus: "Units 1–3: OSI Model, TCP/IP, Routing" },
      { subject: "Design & Analysis of Algorithms",  date: daysFromNow(18), type: "Quiz",     syllabus: "Divide & Conquer, Greedy Algorithms" },
    ],
    assignments: [
      { subject: "Database Management Systems", title: "Mini Project — Library Management System in SQL", deadline: daysFromNow(2),  status: "pending",   weightage: "10 marks" },
      { subject: "Operating Systems",           title: "Report on Process Scheduling Algorithms",          deadline: daysFromNow(3),  status: "pending",   weightage: "5 marks"  },
      { subject: "Computer Networks",           title: "Packet Tracer Simulation — VLAN Setup",            deadline: daysFromNow(8),  status: "pending",   weightage: "10 marks" },
      { subject: "Software Engineering",        title: "SRS Document for Proposed System",                 deadline: daysFromNow(-3), status: "submitted", weightage: "15 marks" },
      { subject: "Web Technologies Lab",        title: "React CRUD Application",                           deadline: daysFromNow(-7), status: "submitted", weightage: "20 marks" },
      { subject: "Design & Analysis of Algorithms", title: "Algorithm Complexity Analysis Report",         deadline: daysFromNow(14), status: "pending",  weightage: "5 marks"  },
    ],
    semesterProgress: 58,
    creditsCompleted: 112,
    creditsRequired: 160,
    backlogs: 0,
    lastUpdated: today.toISOString(),
  };
}

/** Build a detailed, structured text prompt for the AI backend to analyse. */
export function buildWellnessPrompt(data: WellnessData): string {
  const pendingAssignments  = data.assignments.filter(a => a.status === "pending");
  const submittedAssignments = data.assignments.filter(a => a.status === "submitted");
  const lowAttendance = data.subjectAttendance.filter(s => s.percentage < 75);

  const examLines = data.upcomingExams
    .map(e => `  - ${e.subject} (${e.type}) on ${e.date} [${Math.round((new Date(e.date).getTime() - today.getTime()) / 86_400_000)} days away]${e.syllabus ? ": " + e.syllabus : ""}`)
    .join("\n");

  const pendingLines = pendingAssignments
    .map(a => `  - [${a.subject}] "${a.title}" — due ${a.deadline} (${Math.round((new Date(a.deadline).getTime() - today.getTime()) / 86_400_000)} days), ${a.weightage}`)
    .join("\n");

  const attendanceLines = data.subjectAttendance
    .map(s => `  - ${s.subject}: ${s.percentage.toFixed(1)}% (${s.attended}/${s.total} classes)`)
    .join("\n");

  return `You are an expert academic counselor AI. Analyse the following student academic data and generate a comprehensive, personalised Academic Wellness Report.

## Student Academic Data
- **Name**: ${data.studentName}
- **Department**: ${data.department}, Year ${data.year}, Semester ${data.semester}
- **Current CGPA**: ${data.cgpa} / 10.0
- **Overall Attendance**: ${data.overallAttendancePercentage}% (minimum required: 75%)
- **Semester Progress**: ${data.semesterProgress}% complete
- **Credits Completed**: ${data.creditsCompleted} / ${data.creditsRequired}
- **Active Backlogs**: ${data.backlogs}

## Subject-wise Attendance
${attendanceLines}
Subjects below 75% threshold: ${lowAttendance.length > 0 ? lowAttendance.map(s => s.subject).join(", ") : "None"}

## Upcoming Exams (Next 30 Days)
${examLines || "  None scheduled."}

## Assignments
Pending (${pendingAssignments.length}):
${pendingLines || "  None."}
Submitted this semester: ${submittedAssignments.length}

---

Generate the Academic Wellness Report in **exactly** the following Markdown structure. Be specific, practical, and personalized — use the student's name and actual subject names from the data. Do not use generic advice. Calculate the wellness score logically based on the data above.

# Academic Wellness Report — ${data.studentName}

## Overall Academic Wellness Score
[Score out of 100, with brief rationale — 1 sentence]

## Stress Level
[Low / Moderate / High — with one-line reason]

## Key Risk Factors
[Bullet list of 3–5 specific issues identified from the data — e.g., specific subjects with low attendance, upcoming exam pressure, pending assignments]

## Recommendations
[5–7 specific, actionable recommendations using actual subject names and deadlines]

## Today's Priorities
[Numbered list of 3–5 most urgent tasks for today specifically]

## Tomorrow's Deadlines
[List of assignments or exams due within the next 48 hours]

## Personalised 7-Day Study Plan
[Day-by-day plan covering the student's actual subjects and exams, with realistic time blocks]

## Time Management Tips
[3–4 techniques tailored to this student's specific situation — mention subjects by name]

## Motivational Message
[2–3 sentences: acknowledge the student's challenges and end on an encouraging, genuine note]`;
}
